﻿

function mascara(o,f){
    console.log(o);
    v_obj=o
    v_fun=f
    setTimeout("execmascara()",1)
}
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
function mtel(v){
    v=v.replace(/D/g,"");             //Remove tudo o que não é dígito
    v=v.replace(/^(d{2})(d)/g,"($1) $2"); //Coloca parênteses em volta dos dois primeiros dígitos
    v=v.replace(/(d)(d{4})$/,"$1-$2");    //Coloca hífen entre o quarto e o quinto dígitos
    return v;
}
function id( el ){
	return document.getElementById( el );
}


 
 function formatPhone(){ 
        //console.log(domTelefone);
        domTelefone.value = domTelefone.value.replace( /[^\d]/g, '' )
                                 .replace( /^(\d\d)(\d)/, '($1) $2' )
                                 .replace( /(\d{4})(\d)/, '$1-$2' );
        if ( domTelefone.value.length > 14 )  domTelefone.value = stop;
        else stop = domTelefone.value;                 

 }

 function formatMobile(){


        console.log(domTelefone);
        domCelular.value = domCelular.value.replace( /[^\d]/g, '' )
                                 .replace( /^(\d\d)(\d)/, '($1) $2' )
                                 .replace( /(\d{5})(\d)/, '$1-$2' );
        if ( domCelular.value.length > 15 )  domCelular.value = stop;
        else stop = domCelular.value;    

        

 }


