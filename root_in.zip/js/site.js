﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

var contentStatus = false;
var isMobile = false;

function initDOM() {
    var logo = document.getElementById("logo");
    var hamb = document.getElementById("hambBtn");

    if (detec()) {
        hamb.style.display = 'none';
    }

    hamb.addEventListener('click', showContent);
    document.getElementById("pageContent").style = "margin-top: -70px; height:100%;";
    logo.addEventListener('click', hideMenu); 

    //$("#body").removeClass('page-header-fixed page-sidebar-closed-hide-logo page-container-bg-solid');
    //$("#body").addClass('page-header-fixed page-sidebar-closed-hide-logo page-container-bg-solid page-sidebar-closed');
    //$("#ulMenu").addClass('page-sidebar-menu-closed');

    var className = document.getElementById("body").className;

    if (className.includes('page-header-fixed page-sidebar-closed-hide-logo page-container-bg-solid page-sidebar-closed')) {
        if (!detec()) {
            //document.getElementById("hambBtn").style.display = 'block';
        }
    }
 
}

function detec() {

    if (navigator.userAgent.match(/Android/i)
        || navigator.userAgent.match(/webOS/i)
        || navigator.userAgent.match(/iPhone/i)
        || navigator.userAgent.match(/iPad/i)
        || navigator.userAgent.match(/iPod/i)
        || navigator.userAgent.match(/BlackBerry/i)
        || navigator.userAgent.match(/Windows Phone/i)) {
        return true;
    } else {
        return false;
    }
}



function hideMenu() {

    if (detec()) {
        $("#menuModal").modal('show');
    }
    //document.getElementById("hambBtn").click();
   
}

function showContent() {   

    
    if (detec()) {
        if (!contentStatus) {
            document.getElementById("pageContent").style.display = 'none';
            contentStatus = true;
        }
        else {
            document.getElementById("pageContent").style.display = 'block';
            contentStatus = false;
        }
    }
}

initDOM();