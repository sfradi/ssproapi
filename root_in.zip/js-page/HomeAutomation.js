﻿const domBtn1 = document.getElementById("btn1");

function initHomeAutomation() {
    document.getElementById("lblBT1").disable = true;
    document.getElementById("lblBT1").disable = true;
    document.getElementById("myonoffswitch").addEventListener("click", PowerOnOff);

}


function PowerOnOff() {        
    setTimeout(function () {
        if (document.getElementById("myonoffswitch").checked) {
            document.getElementById("myonoffswitch").disable = true;
            $.get("PowerOn?relay=0");           
        } else {
            document.getElementById("myonoffswitch").disable = true;
            $.get("PowerOff?relay=0");           
        }        
    }, 2000);   
}

initHomeAutomation();