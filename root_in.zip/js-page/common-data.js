﻿

async function GetBotsFromAccount(sessionToken, accountId) {
    var accountId = domAccounts.value;
    var listed = false;
    let ajax2 = new XMLHttpRequest();

    try {

        ajax2.open("GET", '/AccessControl/LoadBotsCombo?sessionToken=' + sessionToken + '&accountId=' + accountId, true);
        ajax2.send();
        ajax2.onreadystatechange = function () {

            if (ajax2.readyState != 4 && ajax2.status != 200) return;

            let data = ajax2.responseText;

            return data;

            try {
                let bots = JSON.parse(data);

                if (bots.length === 0) return;

                if (!listed) {

                    return bots;
                }
            }
            catch (e) {
                return;
            };

        }
    }
    catch (e) {
        console.log(e);
    };
}