﻿const domAccounts = document.getElementById("accounts");
const domBots = document.getElementById("bots");

const domCameraType = document.getElementById("camera-type");
const domIsActive = document.getElementById("camera-enabled");
const domDescription = document.getElementById("camera-description");
const domUrl = document.getElementById("camera-url");
const domUserName = document.getElementById("camera-user");
const domCamPassword = document.getElementById("camera-password");

const sessionToken = document.getElementById("sessionToken");
const domSpinner = document.getElementById("spinner");
const domSpinnerSave = document.getElementById("spinner-save");
const domCameras = document.getElementById("action-camera");
const domBtnSub = document.getElementById("btnSub");
const domBtnAdd = document.getElementById("btnAdd");
const domReturnTitle = document.getElementById("return-title");
const domReturnMsg = document.getElementById("return-msg")
const lblRetMsg = document.getElementById("lbl-return-msg");
const confirmDeleteBtn = document.getElementById("delete-btn");

function initDOM() {


    document.getElementById("mode-title").innerHTML = "Edição de item painel acionamentos";

    if (!(domAccounts == null)) {
        domAccounts.addEventListener("change", reloadBotsCombo);
    }
    if (!(domBots == null)) {
        domBots.addEventListener("change", getFromDB);
    }
    if (!(domBtnAdd == null)) {
        // domBtnAdd.addEventListener('click', addAction);
    }
    if (!(confirmDeleteBtn == null)) {
        //confirmDeleteBtn.addEventListener('click', confirmDelete);
    }
    setTimeout(function () {
        var table = $('#kt_datatable').DataTable();
        table
            .clear()
            .draw();
    }, 1000);

    if (!(domSpinner == null)) {
        domSpinner.style.display = 'none';
    }
    if (!(domSpinnerSave == null)) {
        domSpinnerSave.style.display = 'none';
    }
    if (!(domBtnSub == null)) {
        //domBtnSub.addEventListener('click', savePanelData);
    }
    document.getElementById("dTable").style.display = 'none';
}

function reloadBotsCombo() {
    var accountId = domAccounts.value;
    var listed = false;
    let ajax2 = new XMLHttpRequest();

    try {
        ajax2.open("GET", '/AccessControl/LoadBotsCombo?sessionToken=' + sessionToken.value + '&accountId=' + accountId, true);
        ajax2.send();
        ajax2.onreadystatechange = function () {

            if (ajax2.readyState != 4 && ajax2.status != 200) return;

            let data = ajax2.responseText;

            try {
                let bots = JSON.parse(data);

                if (bots.length === 0) return;

                if (!listed) {

                    let _option = document.createElement("option");
                    _option.value = 0;
                    _option.text = "Selecione";
                    domBots.appendChild(_option);

                    bots.forEach(element => {
                        listed = true;
                        let option = document.createElement("option");
                        option.value = element.id;
                        option.text = element.description;
                        domBots.appendChild(option);
                    });
                }
            }
            catch (e) {
                domBots.innerHTML = "";
            };

        }
    }
    catch (e) {
        console.log(e);
    };
}

function getFromDB() {
    var accountId = domAccounts.value;
    var botId = domBots.value;
    var listed = false;
    let ajax2 = new XMLHttpRequest();
    var count = 0;

    document.getElementById("dTable").style.display = 'block';

    domSpinner.style.display = 'inline-block';

    try {

        var table = $('#kt_datatable').DataTable();

        table
            .clear()
            .draw();

        ajax2.open("GET", '/Cameras/GetCamerasList?sessionToken=' + sessionToken.value + '&accountId=' + accountId + '&botId=' + botId, true);
        ajax2.send();
        ajax2.onreadystatechange = function () {

            if (ajax2.readyState != 4 && ajax2.status != 200) return;

            let data = ajax2.responseText;

            if (data == "" || data == null || data == "[]") {
                domSpinner.style.display = 'none';
                return;
            }

            let bots = JSON.parse(data);

            var text = '[';

            bots.forEach(element => {
                text += '{"0":' + element.id + ',"1":"' + element.description + '", "2":"' + element.cameraType + '", "3":"' + element.accountId + '","4":"' + element.botId + '", "5":"' + element.isActive + '", "6":"", "7":"", "8":"", "9":"", "10":"", "11":"", "12":"", "13":"", "14":"", "15":"", "16":"", "17":"", "18":"", "19":"","20":""},';
            });

            text = text.substring(0, text.length - 1);

            text += ']';


            count++;

            if (count > 1) {

                var table = $('#kt_datatable').DataTable();

                table
                    .clear()
                    .draw();

                loadcameraList(text);
            }
        };

    }
    catch (e) {
        console.log(e);
    };

}

function loadcameraList(text) {

    dTable.style.display = 'in-line block';

    try {
        "use strict";
        var KTDatatablesDataSourceHtml = function () {

            //var dataJSONArray = JSON.parse('[[1,"54473-251","GT","San Pedro Ayampuc","Sanford-Halvorson","897 Magdeline Park","sgormally0@dot.gov","Shandra Gormally","1", "", "","","","","","",""]]');

            var dataJSONArray = JSON.parse(text);

            var initTable1 = function () {

                var _table = $('#kt_datatable').DataTable();
                _table.destroy();

                var table = $('#kt_datatable');

                // begin first table
                table.DataTable({
                    responsive: true,
                    data: dataJSONArray,
                    columnDefs: [
                        {
                            targets: 6,
                            title: 'Ações',
                            orderable: false,
                            render: function (data, type, full, meta) {
                                return '\
							<div class="d-flex align-items-center">\
                                <p id="p_'+ full[0] + '" hidden>' + full[1] + '</p>\
                                <input type="text" id="cam_'+ full[0] + '" value=' + full[0] + ' hidden />\
								<a href="javascript:void(0);" onclick="editForm(' + full[0] + ');" class="btn btn-sm btn-clean btn-icon mr-1" title="Editar">\
									<i class="la la-edit"></i>\
								</a >\
								<a href="javascript:void(0);" onclick="deleteForm(' + full[0] + ');" class="btn btn-sm btn-clean btn-icon" title="Deletar">\
									<i class="la la-trash"></i>\
								</a>\
							</div>\
                        ';
                            },
                        },
                        {
                            width: '75px',
                            targets: 5,
                            render: function (data, type, full, meta) {
                                var status = {
                                    0: { 'title': 'Inativo', 'class': ' label-light-danger' },
                                    1: { 'title': 'Ativo', 'class': ' label-light-success' },
                                    2: { 'title': 'Delivered', 'class': ' label-light-danger' },
                                    3: { 'title': 'Canceled', 'class': ' label-light-primary' },
                                    4: { 'title': 'Pending', 'class': ' label-light-primary' },
                                    5: { 'title': 'Info', 'class': ' label-light-info' },
                                    6: { 'title': 'Danger', 'class': ' label-light-danger' },
                                    7: { 'title': 'Warning', 'class': ' label-light-warning' },
                                };

                                if (typeof status[data] === 'undefined') {
                                    return data;
                                }
                                return '<span class="label label-lg font-weight-bold' + status[data].class + ' label-inline">' + status[data].title + '</span>';
                            },
                        },
                        {
                        },
                    ],
                });
                domSpinner.style.display = 'none';
            };

            return {
                //main function to initiate the module
                init: function () {
                    initTable1();
                },
            };
        }();

        jQuery(document).ready(function () {
            KTDatatablesDataSourceHtml.init();
        });
    }
    catch (e) {
        document.getElementById("tbody").innerHTML = "";
    };
}

function editForm(id) {
    //clearForm();
    var _id = id;
    var _accountId = domAccounts.value;
    var _botId = domBots.value;


    document.getElementById("mode-title").innerHTML = "Edição de Cameras (Painel de Comandos)";
    //document.getElementById("panel-id").value = id;
    setTimeout(function () {
        getCamera(_id, _accountId, _botId);
        $("#modalEdit").modal("show");
    }, 1000);
}

function getCamera(id, accountId, botId) {
    var listed = false;
    let ajax2 = new XMLHttpRequest();
    document.getElementById("accountId").value = accountId;
    document.getElementById("botId").value = botId;
    try {

        ajax2.open("GET", '/Cameras/GetCamera?id=' + id + '&accountId=' + accountId + '&botId=' + botId, true);
        ajax2.send();
        ajax2.onreadystatechange = function () {

            if (ajax2.readyState != 4 && ajax2.status != 200) return;

            let data = ajax2.responseText;

            try {
                let cam = JSON.parse(data);

                if (cam.length === 0) return;

                setTimeout(function () {
                    domCameraType.value = cam.cameraType;
                    domDescription.value = cam.description;
                    domUrl.value = cam.url;
                    domUserName.value = cam.user;
                    domCamPassword.value = cam.password;
                    domIsActive.checked = cam.isActive == 1 ? true : false;
                }, 1000);
            }
            catch (e) {

            };
        }
    }
    catch (e) {
        console.log(e);
    };
}


initDOM();