﻿
const formatToBrazilianPhone = (event) => {
    //if (isModifierKey(event)) return;
    let target = event.target;

    let stringInput = target.value.match(/\d+/g);
    if (stringInput === null) return;
    let index = (stringInput.join([]).length < 11 ? 1 : 0);

    let input = target.value.replace(/\D/g, '').substring(0, 11 - index);
    let zip = input.substring(0, 2);
    let middle = input.substring(2, 7 - index);
    let last = input.substring(7 - index, 11 - index);

    if (input.length > 7 - index) { target.value = `(${zip}) ${middle}-${last}`; }
    else if (input.length > 2) { target.value = `(${zip}) ${middle}`; }
    else if (input.length > 0) { target.value = `(${zip}`; }
};


const formatToBrazilianCelPhone = (event) => {
    //if (isModifierKey(event)) return;
    let target = event.target;

    let stringInput = target.value.match(/\d+/g);
    if (stringInput === null) return;
    let index = (stringInput.join([]).length < 12 ? 1 : 0);

    let input = target.value.replace(/\D/g, '').substring(0, 12 - index);
    let zip = input.substring(0, 2);
    let middle = input.substring(2, 8 - index);
    let last = input.substring(8 - index, 12 - index);

    if (input.length > 7 - index) { target.value = `(${zip}) ${middle}-${last}`; }
    else if (input.length > 2) { target.value = `(${zip}) ${middle}`; }
    else if (input.length > 0) { target.value = `(${zip}`; }
};

const functionformatToBrazilianPhone = function (element) {
    let target = element;
    let input = target.value.replace(/\D/g, '').substring(0, 10);
    let zip = input.substring(0, 2);
    let middle = input.substring(2, 6);
    let last = input.substring(6, 10); 


    if (input.length > 7) { target.value = `(${zip}) ${middle}-${last}`; }
    else if (input.length > 2) { target.value = `(${zip}) ${middle}`; }
    else if (input.length > 0) { target.value = `(${zip}`; }
};

const functionformatToBrazilianCelPhone = function (element) {
    let target = element;
    let input = target.value.replace(/\D/g, '').substring(0, 11);
    let zip = input.substring(0, 2);
    let middle = input.substring(2, 7);
    let last = input.substring(7, 11);

    if (input.length > 7) { target.value = `(${zip}) ${middle}-${last}`; }
    else if (input.length > 2) { target.value = `(${zip}) ${middle}`; }
    else if (input.length > 0) { target.value = `(${zip}`; }
};

const keyupFormatToCNPJ = (event) => {
    // if (isModifierKey(event)) return;
    event.target.value = FormatToCNPJ(event.target.value);
};


function FormatToCNPJ(cnpj) {
    let str = cnpj.replace(/\D/g, '').substring(0, 14);
    let first = str.substring(0, 2);
    let second = str.substring(2, 5);
    let third = str.substring(5, 8);
    let fourth = str.substring(8, 12);
    let fifth = str.substring(12, 14);

    if (str.length > 12) { return `${first}.${second}.${third}/${fourth}-${fifth}`; }
    else if (str.length > 8) { return `${first}.${second}.${third}/${fourth}`; }
    else if (str.length > 5) { return `${first}.${second}.${third}`; }
    else if (str.length > 2) { return `${first}.${second}`; }
    else { return `${first}`; }
};