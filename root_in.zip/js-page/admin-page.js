﻿
const domTelefone = document.getElementById('phone');
const domCelular = document.getElementById('celPhone');
const dombtnUpdate = document.getElementById('btnUpdate');
const dombtnDelete = document.getElementById('btnDelete');
const domName = document.getElementById('name');
const domOccupation = document.getElementById('occupation');
const domEmail = document.getElementById('email');
const domList = document.getElementById("sample_1");

const dombtnNew = document.getElementById('btnNew');

var hasSuccess = false;

function initDOM() {


    if (!(domList == null)) {
        document.getElementById("sample_1").style = "border: none";
    }
    

    domTelefone.addEventListener('keyup', formatPhone);
    domCelular.addEventListener('keyup', formatMobile);   
    dombtnUpdate.addEventListener('click', showConfirmModal);
    dombtnDelete.addEventListener('click', showDeleteModal);
    dombtnNew.addEventListener('click', newAdmin);


    setInterval(modalSuccessFunc, 500, 1);
   
   
}

function newAdmin() {

    document.getElementById('formList').style.display = 'none';
    document.getElementById('newAdminForm').style.display = 'block';
   

    dombtnNew.style.display = 'none';
    dombtnUpdate.style.display = 'none';
    dombtnDelete.style.display = 'none';

}

function modalSuccessFunc() {

    var hs = document.getElementById("iHasSuccess").value;

    if (hs == "true") {
        $('#modalSuccess').modal('show');
    }

    document.getElementById("iHasSuccess").value = false;
}


function showConfirmModal() {


    if (domName.value == "" || domEmail.value == "" || domOccupation.value == "") {
        document.getElementById("msgError").innerHTML = "Preencha todos os campos obrigatórios.";
        $('#modalError').modal('show');
        return;
    }
    else {
        document.getElementById("btnConfirmChange").style.display = 'inline';
        document.getElementById("btnConfirmDelete").style.display = 'none';
        document.getElementById("question").innerHTML = "Deseja atualizar o registro do Administrador?";
        $('#confirmModal').modal('show');
        return;
    }    

}



function showDeleteModal() {

    if (domEmail.value == "") {
        document.getElementById("msgError").innerHTML = "Insira o email do Administrador que deseja excluir.";
        $('#modalError').modal('show');
        return;
    }
    else {

        document.getElementById("btnConfirmDelete").style.display = 'inline';
        document.getElementById("btnConfirmChange").style.display = 'none';
        document.getElementById("question").innerHTML = "Deseja excluir o registro do Administrador?";
        $('#confirmModal').modal('show');
        return;
    }

}

    function resp() {


        var hs = document.getElementById("iHasSuccess").value;

        if (hs == "true") {
            $("#btn").click();
        }

    }


initDOM();
resp()