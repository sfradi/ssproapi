﻿const _catch = document.getElementById("catch");
const submit = document.getElementById("submit");

function initLogin() {
    if (!(submit == null)) {
        submit.addEventListener('click', validate);
    }

    _catch.style.display = 'none';

    setTimeout(grecaptcha.reset(), 4000);    
}

function validate() {
    grecaptcha.execute();
}

function recapthca() {
    grecaptcha.execute();
}

function submitLogin() {
    //alert('Captcha is OK.');

    //var sec = '6Le4WNQUAAAAAKqlvogd3i6ijLitskkUq4jr9Yak';
    var resp = grecaptcha.getResponse();
    //var url = "https://www.google.com/recaptcha/api/siteverify?secret=" + sec + "&response=" + resp + "";

    document.getElementById("iresp").value = resp;

    //console.log(url);

    //url = "VerifyRecaptcha";

    ////$.post('https://www.google.com/recaptcha/api/siteverify', { secret : '6Le4WNQUAAAAAKqlvogd3i6ijLitskkUq4jr9Yak', response : resp})
    ////    .done(function (success, challenge_ts, hostname) {
    ////        alert(success);
    ////    });

    //console.log(url);

    //$.post(url, { captchaReponse: resp },
    //    function (data) {
    //        console.log(data.toString());
    //        //alert(response);
    //    });


    _catch.click();
}

initLogin();