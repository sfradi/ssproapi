﻿const domList = document.getElementById("sample_1");
const domInputemail = document.getElementById("txtEmail");
const domInputLogin = document.getElementById("txtLogin");

var isValidEmail = false;
var isValidLogin = false;

function initUserAccountDOM() {

    showModalSuccess(0);

    if (!(domList == null)) {
        document.getElementById("sample_1").style = "border: none";
    }

    if (!(domInputemail == null)) {
        domInputemail.addEventListener('focusout', validateEmailUserRegistered);
    }

    if (!(domInputLogin == null)) {
        domInputLogin.addEventListener('focusout', validateLoginUserRegistered);
    }

    document.getElementById('btnNewUser').addEventListener('click', showFormUser)

}

function showFormUser() {
    document.getElementById('btnNewUser').style.display = 'none';
    document.getElementById('divLista').style.display = 'none';
    document.getElementById('formulario').style.display = 'block';
}

function showModalSuccess(value) {
    if (value == 1) {
        setTimeout(function () {
            $('#modalReturns').modal('show');
        }, 1000);
    }
}

function showModalFail(value) {
    if (value == 1) {
        setTimeout(function () {
            $('#modalReturns').modal('show');
        }, 1000);
    }
}

function checkValideEmail(mail) {

    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
        return (true)
    }
   
    return (false)
}

function validateEmailUserRegistered() {

    var _email = "";

    _email += domInputemail.value;

    var eValid = checkValideEmail(_email);

    if (!eValid) {
        document.getElementById("lblEmail").innerHTML = "Email inválido.";
        document.getElementById("lblEmail").style.display = 'inline';
        isValidEmail = false;
        return true;
    }
    else {

        $.post("CheckEmailUserRegistered", { email: _email })
            .done(function (data) {
                if (data == "1") {
                    document.getElementById("lblEmail").innerHTML = "Email já cadastrado.";
                    document.getElementById("lblEmail").style.display = 'inline';
                    isValidEmail = false;
                    return true;
                } else {
                    document.getElementById("lblEmail").innerHTML = "";
                    document.getElementById("lblEmail").style.display = 'none';
                    isValidEmail = true;
                    return false;
                }
            });
    }
}

function validateLoginUserRegistered() {

    var _userName = "";

    _userName += document.getElementById("txtLogin").value;

    $.post("CheckLoginUserRegistered", { UserName: _userName })
        .done(function (data) {
            if (data == "1") {
                document.getElementById("lblLogin").innerHTML = "Usuário já cadastrado.";
                document.getElementById("lblLogin").style.display = 'inline';
                isValidLogin = false;
                return true;
            }
            else {
                document.getElementById("lblLogin").innerHTML = "";
                document.getElementById("lblLogin").style.display = 'none';
                isValidLogin = true;
                return false;
            }
        });
}

function validateFormData() {

    if (isValidEmail) {
        if (isValidLogin) {
            document.getElementById("btnAdd").click();          
        }
    }
}

initUserAccountDOM();