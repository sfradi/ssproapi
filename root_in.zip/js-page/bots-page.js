﻿//#region DOM 
const domAccounts = document.getElementById("accounts");
const domBotId = document.getElementById("bot-id");
const domBotEnabled = document.getElementById("bot-enabled");
const domDescription = document.getElementById("bot-description");
const domRegUser = document.getElementById("RegUser");
const domRegPass = document.getElementById("RegPass");
const domRegDomain = document.getElementById("RegDomain");
const domSipPort = document.getElementById("SipPort");
const domCCNumber = document.getElementById("CCNumber");
const domToneTime = document.getElementById("ToneTime");
const domSystemType = document.getElementById("SystemTypeId");
const domServiceId = document.getElementById("ServiceId");
const domSpinner = document.getElementById("spinner");
const domSpinnerSave = document.getElementById("spinner-save");
const domBtnSub = document.getElementById("btnSub");
const domBotForm = document.getElementById("bot-form");
const domBtnAdd = document.getElementById("btnAdd");
const domAccountId = document.getElementById("accountId");
const domDbAvailable = document.getElementById("db-available");
const lblRetMsg = document.getElementById("lbl-return-msg");
const domReturnTitle = document.getElementById("return-title");
const domReturnMsg = document.getElementById("return-msg");
const dTable = document.getElementById("dTable");
const domDelBtn = document.getElementById("delete-btn");
var databaseId = 0;
var firstColChanged = true;
//#endregion

function initDOM() {
    if (!(domAccounts == null)) {
        domAccounts.addEventListener("change", getBotsFromDB);
    }
    if (!(domBtnSub == null)) {
        domBtnSub.addEventListener('click', saveBot);
    }
    if (!(domBtnAdd == null)) {
        domBtnAdd.addEventListener('click', addBot);
    }
    if (!(domSpinner == null)) {
        domSpinner.style.display = 'none';
    }
    if (!(domDelBtn == null)) {
        domDelBtn.addEventListener("click", deleteBot);
    }
    getDatabaseAvailable();
    setTimeout(function () {
        var table = $('#kt_datatable').DataTable();
        table
            .clear()
            .draw();                     
    }, 1000);

    dTable.style.display = 'none';
}

function getDatabaseAvailable(id) {
    var listed = false;
    let ajax = new XMLHttpRequest();

    try {

        ajax.open("GET", '/Bots/GetDbAvailable?sessionToken=' + sessionToken.value + "&Id=" + id, true);
        ajax.send();
        ajax.onreadystatechange = function () {

            if (ajax.readyState != 4 && ajax.status != 200) return;

            let data = ajax.responseText;

            try {
                let dbs = JSON.parse(data);

                if (dbs.length === 0) return;

                if (!listed) {

                    let _option = document.createElement("option");
                    _option.value = 0;
                    _option.text = "Selecione";
                    domDbAvailable.appendChild(_option);

                    dbs.forEach(element => {
                        listed = true;
                        let option = document.createElement("option");
                        option.value = element.id;
                        option.text = element.dbName;
                        domDbAvailable.appendChild(option);
                    });
                }
            }
            catch (e) {
                domDbAvailable.innerHTML = "";
            };
        }
    }
    catch (e) {
        console.log(e);
    };
}

function getBotsFromDB() {
    var accountId = domAccounts.value;
    var listed = false;
    let ajax2 = new XMLHttpRequest();
    var count = 0;

    document.getElementById("dTable").style.display = 'block';

    domSpinner.style.display = 'inline-block';

    try {

        var table = $('#kt_datatable').DataTable();

        table
            .clear()
            .draw();

        ajax2.open("GET", '/Bots/GetBotList?sessionToken=' + sessionToken.value + '&accountId=' + accountId, true);
        ajax2.send();
        ajax2.onreadystatechange = function () {

            if (ajax2.readyState != 4 && ajax2.status != 200) return;

            let data = ajax2.responseText;

            if (data == "" || data == null || data == "[]") {
                domSpinner.style.display = 'none';
                return;
            }

            let bots = JSON.parse(data);

            var text = '[';

            bots.forEach(element => {
                text += '{"0":' + element.id + ',"1":"' + element.description + '", "2":"' + element.isActive + '", "3":"","4":"", "5":"", "6":"", "7":"", "8":"", "9":"", "10":"", "11":"", "12":"", "13":"", "14":"", "15":"", "16":"", "17":"", "18":"", "19":"","20":""},';

                //text += '{"0":' + element.id + ',"1":"' + element.description + '", "2":"' + element.isActive + '"},';
            });

            text = text.substring(0, text.length - 1);

            text += ']';


            count++;

            if (count > 1) {

                var table = $('#kt_datatable').DataTable();

                table
                    .clear()
                    .draw();
                loadBotsList(text);
                //$('#kt_datatable').find('td,th').first().remove();
            }
        };
    }
    catch (e) {
        console.log(e);
    };
}

function loadBotsList(text) {

    dTable.style.display = 'in-line block';

    try {
        "use strict";
        var KTDatatablesDataSourceHtml = function () {

            //var dataJSONArray = JSON.parse('[[1,"54473-251","GT","San Pedro Ayampuc","Sanford-Halvorson","897 Magdeline Park","sgormally0@dot.gov","Shandra Gormally","1", "", "","","","","","",""]]');

            var dataJSONArray = JSON.parse(text);

            var initTable1 = function () {

                var _table = $('#kt_datatable').DataTable();
                _table.destroy();


                var table = $('#kt_datatable');

                // begin first table
                table.DataTable({
                    responsive: true,
                    data: dataJSONArray,
                    columnDefs: [
                        {
                            visible: false,
                            targets: 4,
                        },
                        {
                            visible: false,
                            targets: 5,
                        },
                        {
                            visible: false,
                            targets: 6,
                        },
                        {
                            visible: false,
                            targets: 7,
                        },
                        {
                            visible: false,
                            targets: 8,
                        },
                        {
                            targets: 3,
                            title: 'Ações',
                            orderable: false,
                            render: function (data, type, full, meta) {
                                return '\
							<div class="d-flex align-items-center">\
                                <p id="p_'+ full[0] + '" hidden>' + full[1] + '</p>\
                                <input type="text" id="bot_'+ full[0] + '" value=' + full[0] + ' hidden />\
								<a href="javascript:void(0);" onclick="editForm(' + full[0] + ');" class="btn btn-sm btn-clean btn-icon mr-1" title="Editar">\
									<i class="la la-edit"></i>\
								</a >\
								<a href="javascript:void(0);" onclick="deleteForm(' + full[0] + ');" class="btn btn-sm btn-clean btn-icon" title="Deletar">\
									<i class="la la-trash"></i>\
								</a>\
							</div>\
                        ';
                            },
                        },

                        {

                            width: '75px',
                            targets: 2,
                            render: function (data, type, full, meta) {
                                var status = {
                                    0: { 'title': 'Inativo', 'class': ' label-light-danger' },
                                    1: { 'title': 'Ativo', 'class': ' label-light-success' },
                                    2: { 'title': 'Delivered', 'class': ' label-light-danger' },
                                    3: { 'title': 'Canceled', 'class': ' label-light-primary' },
                                    4: { 'title': 'Pending', 'class': ' label-light-primary' },
                                    5: { 'title': 'Info', 'class': ' label-light-info' },
                                    6: { 'title': 'Danger', 'class': ' label-light-danger' },
                                    7: { 'title': 'Warning', 'class': ' label-light-warning' },
                                };

                                if (typeof status[data] === 'undefined') {
                                    return data;
                                }
                                return '<span class="label label-lg font-weight-bold' + status[data].class + ' label-inline">' + status[data].title + '</span>';

                            },
                        },
                        {
                            //targets: [0,1,2,3], visible: false,
                            //targets: [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], visible: false,
                        },
                        //targets: [7], visible: false,

                    ],

                });
                domSpinner.style.display = 'none';

                // table = $('#kt_datatable').DataTable({
                //    columnDefs: [                        
                //        { targets: [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], visible: false, }
                //    ]
                //});
            };

            return {

                //main function to initiate the module
                init: function () {
                    initTable1();
                },

            };

        }();

        jQuery(document).ready(function () {
            KTDatatablesDataSourceHtml.init();
        });



    }
    catch (e) {
        document.getElementById("tbody").innerHTML = "";
    };
}

function loadBotsListReload(text) {
    try {
        "use strict";
        var KTDatatablesDataSourceHtml = function () {

            //var dataJSONArray = JSON.parse('[[1,"54473-251","GT","San Pedro Ayampuc","Sanford-Halvorson","897 Magdeline Park","sgormally0@dot.gov","Shandra Gormally","1", "", "","","","","","",""]]');

            var dataJSONArray = JSON.parse(text);

            var initTable1 = function () {

                var _table = $('#kt_datatable').DataTable();
                _table.destroy();

                var table = $('#kt_datatable');

                // begin first table
                table.DataTable({
                    responsive: true,
                    data: dataJSONArray,
                    columnDefs: [

                        {
                            targets: -1,
                            title: 'Ações',
                            orderable: false,
                            render: function (data, type, full, meta) {
                                return '\
							<div class="d-flex align-items-center">\
                                <p id="p_'+ full[0] + '" hidden>' + full[1] + '</p>\
                                <input type="text" id="bot_'+ full[0] + '" value=' + full[0] + ' hidden />\
								<a href="javascript:void(0);" onclick="editForm(' + full[0] + ');" class="btn btn-sm btn-clean btn-icon mr-1" title="Editar">\
									<i class="la la-edit"></i>\
								</a >\
								<a href="javascript:void(0);" onclick="deleteForm(' + full[0] + ');" class="btn btn-sm btn-clean btn-icon" title="Deletar">\
									<i class="la la-trash"></i>\
								</a>\
							</div>\
                        ';
                            },
                        },
                        {

                            width: '75px',
                            targets: 2,
                            render: function (data, type, full, meta) {
                                var status = {
                                    0: { 'title': 'Inativo', 'class': ' label-light-danger' },
                                    1: { 'title': 'Ativo', 'class': ' label-light-success' },
                                    2: { 'title': 'Delivered', 'class': ' label-light-danger' },
                                    3: { 'title': 'Canceled', 'class': ' label-light-primary' },
                                    4: { 'title': 'Pending', 'class': ' label-light-primary' },
                                    5: { 'title': 'Info', 'class': ' label-light-info' },
                                    6: { 'title': 'Danger', 'class': ' label-light-danger' },
                                    7: { 'title': 'Warning', 'class': ' label-light-warning' },
                                };

                                if (typeof status[data] === 'undefined') {
                                    return data;
                                }
                                return '<span class="label label-lg font-weight-bold' + status[data].class + ' label-inline">' + status[data].title + '</span>';

                            },
                        },
                        {
                            //targets: [0,1,2,3], visible: false,
                            //targets: [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], visible: false,
                        },
                        //targets: [7], visible: false,

                    ],

                });
                domSpinner.style.display = 'none';

                // table = $('#kt_datatable').DataTable({
                //    columnDefs: [                        
                //        { targets: [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], visible: false, }
                //    ]
                //});
            };

            return {

                //main function to initiate the module
                init: function () {
                    initTable1();
                },

            };

        }();

        jQuery(document).ready(function () {
            KTDatatablesDataSourceHtml.init();
        });



    }
    catch (e) {
        document.getElementById("tbody").innerHTML = "";
    };
}

function editForm(id) {
    clearForm();
    var _accountId = domAccounts.value;
    var _botId = id;
    document.getElementById("mode-title").innerHTML = "Edição de Bots (Atendente Yohan)";
    //document.getElementById("panel-id").value = id;
    setTimeout(function () {
        getBot(_accountId, _botId);
        $("#modalEdit").modal("show");
    }, 1000);
}

function showReturnModal(text, type) {
    var color = 'red';
    if (type == 1) {
        color = 'black';
    }
    domSpinnerSave.style.display = 'none';
    domReturnTitle.innerHTML = text;
    domReturnTitle.style.color = color;
    // domReturnMsg.innerHTML = result;
    //domReturnMsg.style.color = "black";
    $("#modalReturn").modal("show");
}

function clearForm() {
    domBotId.readOnly = true;
    domBotId.value = 0;
    domDescription.value = "";
    domRegUser.value = "";
    domRegPass.value = "";
    domRegDomain.value = "";
    domSipPort.value = "";
    domCCNumber.value = "";
    domToneTime.value = "";
    domSystemType.value = 0;
    domServiceId.value = 0;
}

function addBot() {
    clearForm();
    domAccountId.value = domAccounts.value;
    getDatabaseAvailable();
    if (domAccountId.value == "" || domAccountId.value == 0 || domAccountId.value == "Selecione") {
        showReturnModal("Selecione a conta que deseja incluir o novo Bot.")
        return;
    }
    setTimeout(function () {
        $("#modalEdit").modal("show");
    }, 1000);
}

function getBot(accountId, botId) {
    var listed = false;
    let ajax2 = new XMLHttpRequest();
    document.getElementById("accountId").value = accountId;
    document.getElementById("botId").value = botId;
    try {

        ajax2.open("GET", '/Bots/GetBotData?sessionToken=' + sessionToken.value + '&accountId=' + accountId + '&botId=' + botId, true);
        ajax2.send();
        ajax2.onreadystatechange = function () {

            if (ajax2.readyState != 4 && ajax2.status != 200) return;

            let data = ajax2.responseText;

            try {
                let bot = JSON.parse(data);

                if (bot.length === 0) return;

                databaseId = bot.dataBaseId;
                getDatabaseAvailable(databaseId);

                setTimeout(function () {
                    domBotId.value = bot.id;
                    domDescription.value = bot.description;
                    domBotEnabled.checked = bot.isActive == 1 ? true : false;
                    domRegUser.value = bot.regUser;
                    domRegPass.value = bot.regPass;
                    domRegDomain.value = bot.regDomain;
                    domSipPort.value = bot.sipPort;
                    domCCNumber.value = bot.callCenterNumber;
                    domToneTime.value = bot.toneTime;
                    domSystemType.value = bot.systemTypeId;
                    domServiceId.value = bot.serviceId;                 
                    domDbAvailable.value = databaseId;
                }, 1000);
            }
            catch (e) {

            };
        }
    }
    catch (e) {
        console.log(e);
    };
}

function saveBot() {
    if (document.getElementById("db-available").value == 0 || document.getElementById("db-available").value == "Selecione") {
        lblRetMsg.style.color = 'red';
        lblRetMsg.innerHTML = "selecione o banco de dados para alocar a conta.";
        return false;
    }
    if (domBotEnabled.checked) {
        domBotEnabled.value = 1;
    };
    if (!validateForm()) {
        domSpinnerSave.style.display = 'none';
        return;
    }
    var result = "";
    var data = $(domBotForm).serialize();
    $.get('/Bots/SaveBot?sessionToken=' + sessionToken.value + "&dbAvaliable=" + domDbAvailable.value, data, function (_data) {
        result = _data;
    });
    setTimeout(function () {
        if (result == "success") {
            domReturnTitle.innerHTML = "Informação";
            domReturnTitle.style.color = 'blue';
            domReturnMsg.innerHTML = "Atualizado com sucesso.";
            domReturnMsg.style.color = "green";
            $("#modalEdit").modal("hide");
            $("#modalReturn").modal("show");
            domSpinnerSave.style.display = 'none';
            getBotsFromDB();
        }
        else {
            domSpinnerSave.style.display = 'none';
            domReturnTitle.innerHTML = "Ocorreu um erro ao processar a requisição.";
            domReturnTitle.style.color = 'red';
            domReturnMsg.innerHTML = result;
            domReturnMsg.style.color = "black";
            $("#modalReturn").modal("show");
        }
    }, 2000);
}

function deleteForm(id) {
    var desc = document.getElementById("p_" + id).innerHTML;
    domBotId.value = id;
    document.getElementById("question").innerHTML = "Deseja excluir o Bot <b>" + desc + "</b>  da conta selecionada? <br><br> Esta ação é irreversível. ";
    $("#modalDelete").modal("show");
}

function deleteBot() {
    var account = domAccounts.value;
    var botId = domBotId.value;
    var result = "";  
    $.get('/Bots/Delete?sessionToken=' + sessionToken.value + "&botId=" + botId + "&AccountId=" + account, function (_data) {
        result = _data;
    });
    setTimeout(function () {
        if (result == "success") {
            domReturnTitle.innerHTML = "Informação";
            domReturnTitle.style.color = 'blue';
            domReturnMsg.innerHTML = "BOT excluido com sucesso.";
            domReturnMsg.style.color = "green";
            $("#modalEdit").modal("hide");
            $("#modalReturn").modal("show");
            domSpinnerSave.style.display = 'none';
            getBotsFromDB();
        }
        else if (result == "fail") {
            domSpinnerSave.style.display = 'none';
            domReturnTitle.innerHTML = "Ocorreu um erro ao processar a requisição.";
            domReturnTitle.style.color = 'red';
            domReturnMsg.innerHTML = "Verifique os LOGS.";
            domReturnMsg.style.color = "black";
            $("#modalReturn").modal("show");
        }
        else {
            domSpinnerSave.style.display = 'none';
            domReturnTitle.innerHTML = "Ocorreu uma Exceção. Verifique os LOGS.";
            domReturnTitle.style.color = 'red';
            domReturnMsg.innerHTML = result;
            domReturnMsg.style.color = "black";
            $("#modalReturn").modal("show");
        }
    }, 1000);
}

function validateForm() {
    lblRetMsg.style.color = 'red';
    if (domDescription.value == "") {
        lblRetMsg.innerHTML = "Insira a descrição do Bot.";
        return false;
    }
    if (domRegUser.value == "") {
        lblRetMsg.innerHTML = "Insira o ramal do Bot.";
    }
    if (domRegPass.value == "") {
        lblRetMsg.innerHTML = "Insira a senha do ramal do Bot.";
        return false;
    }
    if (domRegDomain.value == "") {
        lblRetMsg.innerHTML = "Insira o Ip/Dominio do Bot.";
        return false;
    }
    if (domSipPort.value == "") {
        lblRetMsg.innerHTML = "Insira a porta Sip do Bot.";
        return false;
    }
    if (domCCNumber.value == "") {
        lblRetMsg.innerHTML = "Insira o ramal de desvio da central.";
        return false;
    }
    if (domToneTime.value == "") {
        lblRetMsg.innerHTML = "Insira o valor do intervalo de discagem DTMF.";
        return false;
    }
    if (domBotEnabled.value == "") {
        lblRetMsg.innerHTML = "Habilitação do Bot não foi reconhecido.";
        return false;
    }
    lblRetMsg.innerHTML = '';
    return true;
}

initDOM();