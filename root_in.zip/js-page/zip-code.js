﻿const zipcode = document.getElementById("zipCode");
const address = document.getElementById("street");
const city = document.getElementById("city");
const state = document.getElementById("state");
const neighborhood = document.getElementById("neighborhood");

function intiZipCode() {
    zipcode.addEventListener('focusout', zipeCodeAddressSearch);
    zipcode.addEventListener('keyup', formatToBrazilianZipeCode);
}

const formatToBrazilianZipeCode = (event) => {
    let target = event.target;
    let cep = target.value.replace(/\D/g, '').substring(0, 9);
    target.value = cep.replace(/D/g, "").replace(/^(\d{5})(\d)/, "$1-$2");
}


const zipeCodeAddressSearch = (event) => {
    let zipeCode = event.target.value.replace(/\D/g, '');
    if (zipeCode == '' || zipeCode.length > 8) return;

    let ajax = new XMLHttpRequest();
    ajax.open("GET", 'https://viacep.com.br/ws/' + zipeCode + '/json/', true);
    ajax.send();
    ajax.onreadystatechange = function () {
        if (ajax.readyState != 4 && ajax.status != 200) return;
        let data = ajax.responseText;
        try {
            let objZipeCodeAddress = JSON.parse(data);
            if (objZipeCodeAddress.erro === true) throw 'CEP inválido!';
            if (!(address === null)) address.value = objZipeCodeAddress.logradouro;
            if (!(neighborhood === null)) neighborhood.value = objZipeCodeAddress.bairro;
            if (!(city === null)) city.value = objZipeCodeAddress.localidade;
            if (!(state === null)) state.value = objZipeCodeAddress.uf;

            ///SearchCitiesByStateAndIncludeToZipeCode(city, '1058', state.value, objZipeCodeAddress.localidade);
        }
        catch (e) {
        };
    };
}

intiZipCode();