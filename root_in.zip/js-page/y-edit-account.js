﻿const domId = document.getElementById("id");
const domServiceId = document.getElementById("serviceId");
const domSystemTypeId = document.getElementById("systemTypeId");
const domDescription = document.getElementById("description");
const domregDomain = document.getElementById("regDomain");
const domRegUser = document.getElementById("regUser");
const domRegPass = document.getElementById("regPass");
const domSipPort = document.getElementById("sipPort");
const domCallCenterNumber = document.getElementById("callCenterNumber"); 
const domToneTime = document.getElementById("toneTime");
const domBtnUpdate = document.getElementById("btnUpdate");
const domBtnNew = document.getElementById("btnNew");
const domBtnDelete = document.getElementById("btnDelete");


function initDOM() {
    if (!(domBtnUpdate == null)) {
        domBtnUpdate.addEventListener("click", UpadateForm);
    }
    if (!(domBtnNew == null)) {
        domBtnNew.addEventListener("click", SaveForm);
    }
    if (!(domBtnDelete == null)) {
        domBtnDelete.addEventListener("click", confirmToDelete);
    }
}


function confirmToDelete() {   
    document.getElementById("question").innerHTML = "Deseja excluir a conta Id " + domId.value + "? </br></br> Esta ação é irreversível. Deseja Continuar?" 
    $("#confirmModal").modal("show");
    //document.getElementById("alertimg").style.display = 'block';
}


function DeleteAccount() {
    //TODOs
}


function SaveForm() {  

    try {
        $.ajax({
            type: "POST",
            url: "Add",
            data: "Id=" + domId.value + "&ServiceId=" + domServiceId.value + "&SystemTypeId=" + domSystemTypeId.value + "&Description=" + domDescription.value +
                "&regDomain=" + domregDomain.value + "&RegUser=" + domRegUser.value + "&RegPass=" + domRegPass.value + "&SipPort=" + domSipPort.value +
                "&CallCenterNumber=" + domCallCenterNumber.value + "&ToneTime=" + domToneTime.value,
            success: function(text) {

                if (text == "success") {
                    document.getElementById("msgSuccess").innerHTML = "Cadastro adicionado com sucesso.";
                    $("#modalSuccess").modal("show");
                } else {
                    document.getElementById("msgError").innerHTML = "Falha ao atualizar o cadastro.";
                    $("#modalError").modal("show");

                }
            }
        });
    } catch (e) {
        console.log(e);
    }

}


function UpadateForm() {  
    $("#confirmModal").modal("hide");

    try {
        $.ajax({
            type: "POST",
            url: "Update",         
            data: "Id=" + domId.value + "&ServiceId=" + domServiceId.value + "&SystemTypeId=" + domSystemTypeId.value + "&Description=" + domDescription.value +
                "&regDomain=" + domregDomain.value + "&RegUser=" + domRegUser.value + "&RegPass=" +  domRegPass.value + "&SipPort=" +domSipPort.value +
                "&CallCenterNumber=" + domCallCenterNumber.value + "&ToneTime=" + domToneTime.value,
            success: function (text) {

                if (text == "success") {
                    document.getElementById("msgSuccess").innerHTML = "Cadastro atualizado com sucesso.";                  
                    $("#modalSuccess").modal("show");
                } else {
                    document.getElementById("msgError").innerHTML = "Falha ao atualizar o cadastro.";
                    $("#modalError").modal("show");

                }
            }
        });
    } catch (e) {
        console.log(e);
    }

}



initDOM();