﻿const btn_cmd_1 = document.getElementById('btn-cmd-1');
const btn_cmd_2 = document.getElementById('btn-cmd-2');
const btn_cmd_3 = document.getElementById('btn-cmd-3');
const btn_cmd_4 = document.getElementById('btn-cmd-4');
const btn_cmd_5 = document.getElementById('btn-cmd-5');
const btn_cmd_6 = document.getElementById('btn-cmd-6');

var cameraIdStatus = 0;

function initDOM() {

    if (!(btn_cmd_1 == null)) {
        btn_cmd_1.addEventListener('click', openModalCommands);
    }
    if (!(btn_cmd_2 == null)) {
        btn_cmd_2.addEventListener('click', openModalCommands);
    }
    if (!(btn_cmd_3 == null)) {
        btn_cmd_3.addEventListener('click', openModalCommands);
    }
    if (!(btn_cmd_4 == null)) {
        btn_cmd_4.addEventListener('click', openModalCommands);
    }
    if (!(btn_cmd_5 == null)) {
        btn_cmd_5.addEventListener('click', openModalCommands);
    }
    if (!(btn_cmd_6 == null)) {
        btn_cmd_6.addEventListener('click', openModalCommands);
    }

    setInterval(function () { verifyImage();}, 200);
}


function openModalCommands(event) {

    if (event.target.id == "btn-cmd-1") {
        document.getElementById('modalTitle').innerHTML = "PORTARIA";       
        $("#modalCommands").modal("show");
        cameraIdStatus = '1';
        document.getElementById('btn-mdl-1').innerHTML = "PORTÃO EXTERNO";
        document.getElementById('btn-mdl-2').innerHTML = "PORTÃO INTERNO";
    }
    if (event.target.id == "btn-cmd-2") {
        document.getElementById('modalTitle').innerHTML = "ECLUSA";
        $("#modalCommands").modal("show");
        cameraIdStatus = '2';
        document.getElementById('btn-mdl-1').innerHTML = "ENTRADA";
        document.getElementById('btn-mdl-2').innerHTML = "SAIDA";
    }
    if (event.target.id == "btn-cmd-3") {
        document.getElementById('modalTitle').innerHTML = "SOCIAL";
        $("#modalCommands").modal("show");
        cameraIdStatus = '3';
        document.getElementById('btn-mdl-1').innerHTML = "HALL SOCIAL";
        document.getElementById('btn-mdl-2').innerHTML = "ELEVADOR SOCIAL";
    }
    if (event.target.id == "btn-cmd-4") {
        document.getElementById('modalTitle').innerHTML = "SERVIÇO";
        $("#modalCommands").modal("show");
        cameraIdStatus = '4';
        document.getElementById('btn-mdl-1').innerHTML = "ENTRADA SERVIÇO";
        document.getElementById('btn-mdl-2').innerHTML = "ELEVADOR SERVIÇO";
    }
    if (event.target.id == "btn-cmd-5") {
        document.getElementById('modalTitle').innerHTML = "GARAGEM SUPERIOR";
        $("#modalCommands").modal("show");
        cameraIdStatus = '5';
        document.getElementById('btn-mdl-1').innerHTML = "PORTÃO EXTERNO";
        document.getElementById('btn-mdl-2').innerHTML = "PORTÃO INTERNO";
    }
    if (event.target.id == "btn-cmd-6") {
        document.getElementById('modalTitle').innerHTML = "GRARAGEM INFERIOR";
        $("#modalCommands").modal("show");
        cameraIdStatus = '6';
        document.getElementById('btn-mdl-1').innerHTML = "PORTÃO EXTERNO";
        document.getElementById('btn-mdl-2').innerHTML = "PORTÃO INTERNO";
    }
}


function verifyImage() {
    if (cameraIdStatus == '1') {
        document.getElementById("imgcamModal").src = document.getElementById("imgcam1").src;
    }
    if (cameraIdStatus == '2') {
        document.getElementById("imgcamModal").src = document.getElementById("imgcam2").src;
    }
    if (cameraIdStatus == '3') {
        document.getElementById("imgcamModal").src = document.getElementById("imgcam3").src;
    }
    if (cameraIdStatus == '4') {
        document.getElementById("imgcamModal").src = document.getElementById("imgcam4").src;
    }
    if (cameraIdStatus == '5') {
        document.getElementById("imgcamModal").src = document.getElementById("imgcam5").src;
    }
    if (cameraIdStatus == '6') {
        document.getElementById("imgcamModal").src = document.getElementById("imgcam6").src;
    }
}

initDOM();