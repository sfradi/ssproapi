﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Yohan.API.wwwroot.js_page
{
    public class commands_page
    {
    }
}
