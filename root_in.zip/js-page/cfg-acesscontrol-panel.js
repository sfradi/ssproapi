﻿const domAccounts = document.getElementById("accounts");
const domBots = document.getElementById("bots");
const sessionToken = document.getElementById("sessionToken");
const domSpinner = document.getElementById("spinner");
const domSpinnerSave = document.getElementById("spinner-save");
const domCameras = document.getElementById("action-camera");
const domBtnSub = document.getElementById("btnSub");
const domBtnAdd = document.getElementById("btnAdd");
const domActionDescription = document.getElementById("action-description");
const domActionPosition = document.getElementById("action-position");
const domActionCamera = document.getElementById("action-camera");
const domBtn1Label = document.getElementById("action-btn1-description");
const domBtn2Label = document.getElementById("action-btn2-description");
const domChkBtn1 = document.getElementById("action-btn1-enabled");
const domChkBtn2 = document.getElementById("action-btn2-enabled");
const domActionDevice1 = document.getElementById("action-device-list-1");
const domActionDevice2 = document.getElementById("action-device-list-2");
const domIsActive = document.getElementById("action-enabled");
const domReturnTitle = document.getElementById("return-title");
const domReturnMsg = document.getElementById("return-msg")
const lblRetMsg = document.getElementById("lbl-return-msg");
const confirmDeleteBtn = document.getElementById("delete-btn");


function initDOM() {

    document.getElementById("mode-title").innerHTML = "Edição de item painel acionamentos";

    if (!(domAccounts == null)) {
        domAccounts.addEventListener("change", reloadBotsCombo);
    }
    if (!(domBots == null)) {
        domBots.addEventListener("change", getFromDB);
    }
    if (!(domBtnAdd == null)) {
        domBtnAdd.addEventListener('click', addAction);
    }
    if (!(confirmDeleteBtn == null)) {
        confirmDeleteBtn.addEventListener('click', confirmDelete);
    }
    setTimeout(function () {
        var table = $('#kt_datatable').DataTable();
        table
            .clear()
            .draw();
    }, 1000);
    if (!(domSpinner == null)) {
        domSpinner.style.display = 'none';
    }
    if (!(domSpinnerSave == null)) {
        domSpinnerSave.style.display = 'none';
    }
    if (!(domBtnSub == null)) {
        domBtnSub.addEventListener('click', savePanelData);
    }
    document.getElementById("dTable").style.display = 'none';
}

function reloadBotsCombo() {
    var accountId = domAccounts.value;
    var listed = false;
    let ajax2 = new XMLHttpRequest();

    try {

        ajax2.open("GET", '/AccessControl/LoadBotsCombo?sessionToken=' + sessionToken.value + '&accountId=' + accountId, true);
        ajax2.send();
        ajax2.onreadystatechange = function () {

            if (ajax2.readyState != 4 && ajax2.status != 200) return;

            let data = ajax2.responseText;

            try {
                let bots = JSON.parse(data);

                if (bots.length === 0) return;

                if (!listed) {

                    let _option = document.createElement("option");
                    _option.value = 0;
                    _option.text = "Selecione";
                    domBots.appendChild(_option);

                    bots.forEach(element => {
                        listed = true;
                        let option = document.createElement("option");
                        option.value = element.id;
                        option.text = element.description;
                        domBots.appendChild(option);
                    });
                }
            }
            catch (e) {
                domBots.innerHTML = "";
            };

        }
    }
    catch (e) {
        console.log(e);
    };
}

function getFromDB() {
    var accountId = domAccounts.value;
    var botId = domBots.value;
    var listed = false;
    let ajax2 = new XMLHttpRequest();
    var count = 0;

    document.getElementById("dTable").style.display = 'block';

    domSpinner.style.display = 'inline-block';

    try {

        var table = $('#kt_datatable').DataTable();

        table
            .clear()
            .draw();

        ajax2.open("GET", '/AccessControl/GetList?sessionToken=' + sessionToken.value + '&accountId=' + accountId + '&botId=' + botId, true);
        ajax2.send();
        ajax2.onreadystatechange = function () {

            if (ajax2.readyState != 4 && ajax2.status != 200) return;

            let data = ajax2.responseText;

            if (data == "" || data == null || data == "[]") {
                domSpinner.style.display = 'none';
                return;
            }

            let bots = JSON.parse(data);

            var text = '[';

            bots.forEach(element => {
                text += '{"0":' + element.id + ',"1":"' + element.description + '", "2":"' + element.panelPosition + '", "3":"' + element.btnLabel1 + '","4":"' + element.btnLabel2 + '", "5":"' + element.cameraId + '", "6":"' + element.accountId + '", "7":"' + element.botId + '", "8":"' + element.isActive + '", "9":"", "10":"", "11":"", "12":"", "13":"", "14":"", "15":"", "16":"", "17":"", "18":"", "19":"","20":""},';
            });

            text = text.substring(0, text.length - 1);

            text += ']';


            count++;

            if (count > 1) {

                var table = $('#kt_datatable').DataTable();

                table
                    .clear()
                    .draw();

                loadList(text);
            }
        };

    }
    catch (e) {
        console.log(e);
    };

}

function loadList(text) {
    try {
        "use strict";
        var KTDatatablesDataSourceHtml = function () {

            //var dataJSONArray = JSON.parse('[[1,"54473-251","GT","San Pedro Ayampuc","Sanford-Halvorson","897 Magdeline Park","sgormally0@dot.gov","Shandra Gormally","1", "", "","","","","","",""]]');

            var dataJSONArray = JSON.parse(text);

            var initTable1 = function () {
                var table = $('#kt_datatable');

                var _table = $('#kt_datatable').DataTable();
                _table.destroy();

                // begin first table
                table.DataTable({
                    responsive: true,
                    data: dataJSONArray,
                    columnDefs: [
                        {
                            targets: -1,
                            title: 'Actions',
                            orderable: false,
                            render: function (data, type, full, meta) {
                                return '\
							<div class="d-flex align-items-center">\
                                <p id="p_'+ full[0] + '" hidden>' + full[1] + '</p>\
                                <input type="text" id="acc_'+ full[0] + '" value=' + full[6] + ' hidden />\
                                <input type="text" id="bot_'+ full[0] + '" value=' + full[7] + ' hidden />\
								<a href="javascript:void(0);" onclick="editForm(' + full[0] + ');" class="btn btn-sm btn-clean btn-icon mr-1" title="Editar">\
									<i class="la la-edit"></i>\
								</a >\
								<a href="javascript:void(0);" onclick="deleteForm(' + full[0] + ');" class="btn btn-sm btn-clean btn-icon" title="Deletar">\
									<i class="la la-trash"></i>\
								</a>\
							</div>\
						';
                            },
                        },
                        {
                            width: '75px',
                            targets: 8,
                            render: function (data, type, full, meta) {
                                var status = {
                                    0: { 'title': 'Inativo', 'class': ' label-light-danger' },
                                    1: { 'title': 'Ativo', 'class': ' label-light-success' },
                                    2: { 'title': 'Delivered', 'class': ' label-light-danger' },
                                    3: { 'title': 'Canceled', 'class': ' label-light-primary' },
                                    4: { 'title': 'Pending', 'class': ' label-light-primary' },
                                    5: { 'title': 'Info', 'class': ' label-light-info' },
                                    6: { 'title': 'Danger', 'class': ' label-light-danger' },
                                    7: { 'title': 'Warning', 'class': ' label-light-warning' },
                                };
                                if (typeof status[data] === 'undefined') {
                                    return data;
                                }
                                return '<span class="label label-lg font-weight-bold' + status[data].class + ' label-inline">' + status[data].title + '</span>';
                            },
                        },
                    ],
                });
                domSpinner.style.display = 'none';

            };

            return {

                //main function to initiate the module
                init: function () {
                    initTable1();
                },

            };

        }();

        jQuery(document).ready(function () {
            KTDatatablesDataSourceHtml.init();
        });



    }
    catch (e) {
        //document.getElementById("tbody").innerHTML = "";
    };
}

function deleteForm(id) {
    var desc = document.getElementById("p_" + id).innerHTML;
    var account = document.getElementById("acc_" + id).value;
    var bot = document.getElementById("bot_" + id).value;
    document.getElementById("panel-id").value = id;

    document.getElementById("question").innerHTML = "Deseja excluir o painel <b>" + desc + "</b>  da conta selecionada? <br><br> Esta ação é irreversível. ";
    $("#modalDelete").modal("show");
}

function confirmDelete() {
    var domForm = document.getElementById("edit-panel-form");
    var domAccountId = document.getElementById("accountId");
    var domBotId = document.getElementById("botId");
    domAccountId.value = domAccounts.value;
    domBotId.value = domBots.value;
    domSpinnerSave.style.display = 'inline-block';

    try {

        var result = "";
        var data = $(domForm).serialize();
        $.get('/accesscontrol/DeletePanel?sessionToken=' + sessionToken.value, data, function (_data) {
            result = _data;
        });

        setTimeout(function () {
            if (result == "success") {
                domReturnTitle.innerHTML = "Informação";
                domReturnTitle.style.color = 'blue';
                domReturnMsg.innerHTML = "Excluido com sucesso.";
                domReturnMsg.style.color = "green";
                $("#modalEdit").modal("hide");
                $("#modalReturn").modal("show");
                getFromDB();
                domSpinnerSave.style.display = 'none';
            }
            else {
                domSpinnerSave.style.display = 'none';
                domReturnTitle.innerHTML = "Ocorreu um erro ao processar a requisição.";
                domReturnTitle.style.color = 'red';
                domReturnMsg.innerHTML = result;
                domReturnMsg.style.color = "black";
                $("#modalReturn").modal("show");
            }
        }, 2000);

    }
    catch (e) {
        console.log(e);
    };

}

function editForm(id) {
    var _accountId = document.getElementById("acc_" + id).value;
    var _botId = document.getElementById("bot_" + id).value;

    document.getElementById("mode-title").innerHTML = "Edição de item painel acionamentos";

    document.getElementById("panel-id").value = id;

    getCameras(_accountId, _botId);

    getDevices(_accountId, _botId);

    setTimeout(function () {
        getAction(_accountId, _botId, id);
        $("#modalEdit").modal("show");
    }, 1000);
}

function getCameras(accountId, botId) {
    var listed = false;
    let ajax2 = new XMLHttpRequest();

    try {

        ajax2.open("GET", '/AccessControl/GetCameraList?sessionToken=' + sessionToken.value + '&accountId=' + accountId + '&botId=' + botId, true);
        ajax2.send();
        ajax2.onreadystatechange = function () {

            if (ajax2.readyState != 4 && ajax2.status != 200) return;

            let data = ajax2.responseText;

            try {
                let cams = JSON.parse(data);

                if (cams.length === 0) return;

                if (!listed) {

                    let _option = document.createElement("option");
                    _option.value = 0;
                    _option.text = "Selecione";
                    domCameras.appendChild(_option);

                    cams.forEach(element => {
                        listed = true;
                        let option = document.createElement("option");
                        option.value = element.id;
                        option.text = element.description;
                        domCameras.appendChild(option);
                    });
                }
            }
            catch (e) {
                domCameras.innerHTML = "";
            };
        }
    }
    catch (e) {
        console.log(e);
    };
}

function getDevices(accountId, botId) {
    var listed = false;
    let ajax2 = new XMLHttpRequest();

    try {

        ajax2.open("GET", '/AccessControl/GetDevicesList?sessionToken=' + sessionToken.value + '&accountId=' + accountId + '&botId=' + botId, true);
        ajax2.send();
        ajax2.onreadystatechange = function () {

            if (ajax2.readyState != 4 && ajax2.status != 200) return;

            let data = ajax2.responseText;

            try {
                let devices = JSON.parse(data);

                if (devices.length === 0) return;

                if (!listed) {

                    let _option = document.createElement("option");
                    let _option2 = document.createElement("option");
                    _option.value = 0;
                    _option.text = "Selecione";
                    _option2.value = 0;
                    _option2.text = "Selecione";
                    domActionDevice1.appendChild(_option);
                    domActionDevice2.appendChild(_option2);

                    devices.forEach(element => {
                        listed = true;
                        let option = document.createElement("option");
                        let option2 = document.createElement("option");
                        option.value = element.id;
                        option.text = element.description;
                        domActionDevice1.appendChild(option);
                        option2.value = element.id;
                        option2.text = element.description;
                        domActionDevice2.appendChild(option2);
                    });
                }
            }
            catch (e) {
                //domActionDevice1.innerHTML = "";
                // domActionDevice2.innerHTML = "";
            };
        }
    }
    catch (e) {
        console.log(e);
    };
}

function getAction(accountId, botId, actionId) {
    var listed = false;
    let ajax2 = new XMLHttpRequest();
    document.getElementById("accountId").value = accountId;
    document.getElementById("botId").value = botId;

    try {

        ajax2.open("GET", '/AccessControl/GetConfigAction?sessionToken=' + sessionToken.value + '&accountId=' + accountId + '&botId=' + botId + '&actionId=' + actionId, true);
        ajax2.send();
        ajax2.onreadystatechange = function () {

            if (ajax2.readyState != 4 && ajax2.status != 200) return;

            let data = ajax2.responseText;

            try {
                let action = JSON.parse(data);

                if (action.length === 0) return;

                domActionDescription.value = action.description;
                domCameras.value = action.cameraId;
                domActionPosition.value = action.panelPosition;
                domBtn1Label.value = action.btnLabel1;
                domBtn2Label.value = action.btnLabel2;
                domChkBtn1.checked = action.btn1Active;
                domChkBtn2.checked = action.btn2Active;
                domActionDevice1.value = action.btn1DeviceId;
                domActionDevice2.value = action.btn2DeviceId;
                domIsActive.checked = action.isActive;

            }
            catch (e) {

            };
        }
    }
    catch (e) {
        console.log(e);
    };
}

function addAction() {
    var listed = false;
    let ajax2 = new XMLHttpRequest();
    var accountId = domAccounts.value;
    var botId = domBots.value;
    document.getElementById("panel-id").value = 0;


    if (accountId == "" || accountId == "Selecione" || accountId == "0" || botId == "" || botId == "Selecione" || botId == "0") {
        domReturnTitle.innerHTML = "Atenção!";
        domReturnTitle.style.color = 'red';
        domReturnMsg.innerHTML = "Selecione a conta que deseja incluir um painel de acionamento.";
        domReturnMsg.style.color = "black";
        $("#modalReturn").modal("show");
        return;
    }

    document.getElementById("mode-title").innerHTML = "Adicionar novo item painel acionamentos";

    domActionDescription.value = "";
    domCameras.value = 0;
    domActionPosition.value = 0;
    domBtn1Label.value = "";
    domBtn2Label.value = "";
    domChkBtn1.checked = true;
    domChkBtn2.checked = true;
    domActionDevice1.value = 0;
    domActionDevice2.value = 0;
    domIsActive.checked = true;

    getCameras(accountId, botId);
    getDevices(accountId, botId);

    try {
        ajax2.open("GET", '/AccessControl/GetActionCounter?sessionToken=' + sessionToken.value + '&accountId=' + accountId + '&botId=' + botId, true);
        ajax2.send();
        ajax2.onreadystatechange = function () {
            if (ajax2.readyState != 4 && ajax2.status != 200) return;
            let count = ajax2.responseText;
            try {
                let actions = JSON.parse(count);
                if (actions == 6) {
                    domReturnTitle.innerHTML = "Limite de painéis atingido.";
                    domReturnTitle.style.color = 'red';
                    domReturnMsg.innerHTML = "O limite total são de 6 painéis por conta.";
                    domReturnMsg.style.color = "black";
                    $("#modalReturn").modal("show");
                    return;
                }


                setTimeout(function () {
                    $("#modalEdit").modal("show");
                }, 1000);
            }
            catch (e) {
            };
        }
    }
    catch (e) {
        console.log(e);
    };
}

function savePanelData() {
    var domForm = document.getElementById("edit-panel-form");
    var domAccountId = document.getElementById("accountId");
    var domBotId = document.getElementById("botId");
    domAccountId.value = domAccounts.value;
    domBotId.value = domBots.value;
    domSpinnerSave.style.display = 'inline-block';

    if (domChkBtn1.checked) {
        domChkBtn1.value = true;
    } else { domChkBtn1.value = false; };
    if (domChkBtn2.checked) {
        domChkBtn2.value = true;
    } else { domChkBtn2.value = false; };;
    if (domIsActive.checked) {
        domIsActive.value = 1;
    };

    if (!validateForm()) {
        domSpinnerSave.style.display = 'none';
        return;
    }

    var result = "";
    var data = $(domForm).serialize();
    $.get('/accesscontrol/SavePanelData?sessionToken=' + sessionToken.value, data, function (_data) {
        result = _data;
    });

    setTimeout(function () {
        if (result == "success") {
            domReturnTitle.innerHTML = "Informação";
            domReturnTitle.style.color = 'blue';
            domReturnMsg.innerHTML = "Atualizado com sucesso.";
            domReturnMsg.style.color = "green";
            $("#modalEdit").modal("hide");
            $("#modalReturn").modal("show");
            getFromDB();
            domSpinnerSave.style.display = 'none';
        }
        else {
            domSpinnerSave.style.display = 'none';
            domReturnTitle.innerHTML = "Ocorreu um erro ao processar a requisição.";
            domReturnTitle.style.color = 'red';
            domReturnMsg.innerHTML = result;
            domReturnMsg.style.color = "black";
            $("#modalReturn").modal("show");
        }
    }, 2000);
}

function validateForm() {
    lblRetMsg.style.color = 'red';

    if (domActionDescription.value == "") {
        lblRetMsg.innerHTML = "Insira a descrição do painel.";
        return false;
    }
    if (domActionCamera.value == "") {
        domActionCamera.value = 0;
    }
    if (domBtn1Label.value == "" && domChkBtn1.value == "true") {
        lblRetMsg.innerHTML = "Insira a descrição do botão 1.";
        return false;
    }
    if (domBtn2Label.value == "" && domChkBtn2.value == "true") {
        lblRetMsg.innerHTML = "Insira a descrição do botão 2.";
        return false;
    }
    if (domChkBtn1.value == "") {
        lblRetMsg.innerHTML = "Habilitação do botão 1 não foi reconhecido.";
        return false;
    }
    if (domChkBtn2.value == "") {
        lblRetMsg.innerHTML = "Habilitação do botão 2 não foi reconhecido.";
        return false;
    }
    if (domActionDevice1.value == "" && domChkBtn1.value == "true" || domActionDevice1.value == "0" && domChkBtn1.value == "true") {
        lblRetMsg.innerHTML = "Selecione o equipamento para o botão 1.";
        return false;
    }
    if (domActionDevice2.value == "" && domChkBtn2.value == "true" || domActionDevice2.value == "0" && domChkBtn2.value == "true") {
        lblRetMsg.innerHTML = "Selecione o equipamento para o botão 2.";
        return false;
    }
    if (domIsActive.value == "") {
        lblRetMsg.innerHTML = "Habilitação do painel não foi reconhecido.";
        return false;
    }

    lblRetMsg.innerHTML = '';
    return true;
}

initDOM();

