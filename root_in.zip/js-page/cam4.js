﻿var d = new Date();
var unixtime = d.getTime();

function initDOMCam4() {
    setUserAgent(window, "Android");
    setInterval(function () { getCam4(); }, 200);
}

function getCam4() {
    unixtime = unixtime + 100;
    $.get("Video/GetImage4?unixtime=" + unixtime + "&cam=4", function (data) {
        document.getElementById("imgcam4").src = "data:image/png;base64," + data;
    });
}

function setUserAgent(window, userAgent) {
    // Works on Firefox, Chrome, Opera and IE9+
    if (navigator.__defineGetter__) {
        navigator.__defineGetter__('userAgent', function () {
            return userAgent;
        });
    } else if (Object.defineProperty) {
        Object.defineProperty(navigator, 'userAgent', {
            get: function () {
                return userAgent;
            }
        });
    }
    // Works on Safari
    if (window.navigator.userAgent !== userAgent) {
        var userAgentProp = {
            get: function () {
                return userAgent;
            }
        };
        try {
            Object.defineProperty(window.navigator, 'userAgent', userAgentProp);
        } catch (e) {
            window.navigator = Object.create(navigator, {
                userAgent: userAgentProp
            });
        }
    }
}

initDOMCam4();