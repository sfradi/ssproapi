﻿const sessionToken = document.getElementById('sessionToken');
const domAccountList = document.getElementById("account-list");
const domPhone = document.getElementById("phone");
const domCelPhone = document.getElementById("celPhone");
const domCnpj = document.getElementById("cnpj") 
const domAccountId = document.getElementById("account-id");
const domName = document.getElementById("name");
const domEmail = document.getElementById("email");
const domZipCode = document.getElementById("zipCode");
const domStreet = document.getElementById("street");
const domNumber = document.getElementById("number");
const domNeigborhood = document.getElementById("neighborhood");
const domCity = document.getElementById("city");
const domState = document.getElementById("state");
const domForm = document.getElementById("account-form");
const domBtnAdd = document.getElementById("btnAdd");
const domBtnSub = document.getElementById("btnSub");
const domReturnTitle = document.getElementById("return-title");
const domReturnMsg = document.getElementById("return-msg")
const lblRetMsg = document.getElementById("lbl-return-msg");
const domSpinnerSave = document.getElementById("spinner-save");

function initDOM() {
    if (!(domBtnSub == null)) {
        domBtnSub.addEventListener('click', addAccount);
    }
    if (!(domAccountList == null)) {
        domAccountList.addEventListener('change', getAccount);
    }
    if (!(domBtnAdd == null)) {
        domBtnAdd.addEventListener('click', clearForm);
    }
    if (!(domPhone == null)) {
        domPhone.addEventListener("keyup", formatToBrazilianPhone);
        domPhone.addEventListener("change", functionformatToBrazilianPhone);
    }
    if (!(domCelPhone == null)) {
        domCelPhone.addEventListener("keyup", formatToBrazilianCelPhone);
    }
    if (!(domCnpj == null)) {
        domCnpj.addEventListener("keyup", keyupFormatToCNPJ);
    }    
}

function getAccountList() {    
    var listed = false;
    let ajax = new XMLHttpRequest();

    $("#account-list").empty();

    try {

        ajax.open("GET", '/Account/GetAccountList?sessionToken=' + sessionToken.value, true);
        ajax.send();
        ajax.onreadystatechange = function () {

            if (ajax.readyState != 4 && ajax.status != 200) return;

            let data = ajax.responseText;

            try {
                let accounst = JSON.parse(data);

                if (accounst.length === 0) return;

                if (!listed) {

                    let _option = document.createElement("option");
                    _option.value = 0;
                    _option.text = "Selecione";
                    domAccountList.appendChild(_option);

                    accounst.forEach(element => {
                        listed = true;
                        let option = document.createElement("option");
                        option.value = element.id;
                        option.text = element.name;
                        domAccountList.appendChild(option);
                    });
                }
            }
            catch (e) {
                domAccountList.innerHTML = "";
            };

        }
    }
    catch (e) {
        console.log(e);
    };

}

function getAccount() {
    var accountId = domAccountList.value;
    let ajax2 = new XMLHttpRequest();

    try {
        ajax2.open("GET", '/Account/GetAccountById?sessionToken=' + sessionToken.value + '&accountId=' + accountId, true);
        ajax2.send();
        ajax2.onreadystatechange = function () {
            if (ajax2.readyState != 4 && ajax2.status != 200) return;
            let account = ajax2.responseText;
            try {
                let _account = JSON.parse(account);

                domPhone.value = "";
                domAccountId.value = _account.id;
                domCnpj.value =  FormatToCNPJ(_account.cpfcnpj);
                domName.value = _account.name;
                domEmail.value = _account.email;
                domPhone.value = _account.phone;
                domCelPhone.value = _account.celPhone;
                domZipCode.value = _account.zipCode;
                domStreet.value = _account.address;
                domNumber.value = _account.number;
                domNeigborhood.value = _account.neighborhood;
                domCity.value = _account.city;
                domState.value = _account.state;
                functionformatToBrazilianPhone(domPhone);
                functionformatToBrazilianCelPhone(domCelPhone);
                domCnpj.readOnly = true;
            }
            catch (e) {
            };
        }
    }
    catch (e) {
        console.log(e);
    };

}

function clearForm() {
    domAccountId.value = 0;
    domCnpj.value = "";
    domName.value = "";
    domEmail.value = "";
    domPhone.value = "";
    domCelPhone.value = "";
    domZipCode.value = "";
    domStreet.value = "";
    domNumber.value = "";
    domNeigborhood.value = "";
    domCity.value = "";
    domState.value = "";
    domCnpj.readOnly = false;
}

function addAccount() {
    var accountId = domAccountId.value;

    if (accountId != 0) {
        updateAccount();
        return;
    }
    var result = "";
    var data = $(domForm).serialize();
    $.get('/Account/AddAccount?sessionToken=' + sessionToken.value, data, function (_data) {
        result = _data;
    });


    setTimeout(function () {
        if (result == "success") {
            domReturnTitle.innerHTML = "Informação";
            domReturnTitle.style.color = 'blue';
            domReturnMsg.innerHTML = "Conta adicionada com sucesso.";
            domReturnMsg.style.color = "green";
            $("#modalReturn").modal("show");
            domSpinnerSave.style.display = 'none';
            getAccountList();
        }
        else if (result == "fail") {
            domReturnTitle.innerHTML = "Falha";
            domReturnTitle.style.color = 'red';
            domReturnMsg.innerHTML = "Ocorreu uma falha ao executar a requisição";
            domReturnMsg.style.color = "black";
            $("#modalReturn").modal("show");
            domSpinnerSave.style.display = 'none';
        }
        else {
            domReturnTitle.innerHTML = "Falha";
            domReturnTitle.style.color = 'red';
            domReturnMsg.innerHTML = result;
            domReturnMsg.style.color = "black";
            $("#modalReturn").modal("show");
            domSpinnerSave.style.display = 'none';
        }

    }, 2000);

}


function updateAccount() {
    var accountId = domAccountId.value;
    domSpinnerSave.style.display = 'inline-block';

    var result = "";
    var data = $(domForm).serialize();
    $.get('/Account/updateAccount?sessionToken=' + sessionToken.value, data, function (_data) {
        result = _data;
    });

    setTimeout(function () {
        if (result == "success") {
            domReturnTitle.innerHTML = "Informação";
            domReturnTitle.style.color = 'blue';
            domReturnMsg.innerHTML = "Atualizado com sucesso.";
            domReturnMsg.style.color = "green";
            $("#modalReturn").modal("show");
            domSpinnerSave.style.display = 'none';
            getAccountList();
        }
        else if (result == "fail")
        {
            domReturnTitle.innerHTML = "Falha";
            domReturnTitle.style.color = 'red';
            domReturnMsg.innerHTML = "Ocorreu uma falha ao executar a requisição";
            domReturnMsg.style.color = "black";
            $("#modalReturn").modal("show");
            domSpinnerSave.style.display = 'none';
        }
        else {
            domReturnTitle.innerHTML = "Falha";
            domReturnTitle.style.color = 'red';
            domReturnMsg.innerHTML = result;
            domReturnMsg.style.color = "black";
            $("#modalReturn").modal("show");
            domSpinnerSave.style.display = 'none';
        }

        }, 2000);
}


initDOM();