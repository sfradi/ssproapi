﻿const dombtnNew = document.getElementById('btnNew');
const domUnity = document.getElementById("unity");
const dombtnDelete = document.getElementById('btnDelete');
const domList = document.getElementById("sample_1");

function initUnityDOM() {


    if (!(domList == null)) {
        document.getElementById("sample_1").style = "border: none";
    }


    try {
        dombtnNew.addEventListener('click', newUnity);
    } catch (e) {
    }

    try {
        dombtnDelete.addEventListener('click', showDeleteModalUnity);
    } catch (e) {
    }

    setInterval(modalSuccessFunc, 500, 1);
   
}

function newUnity() {

    document.getElementById("newUnityForm").hidden = false;
    document.getElementById("formList").hidden = true;
    dombtnNew.style.display = 'none';
}

function hiddenAddButton() {
    document.getElementById("btnAdd").style.display = 'none';
}

function modalSuccessFunc() {

    var hs = document.getElementById("iHasSuccess").value;

    if (hs == "true") {
        $('#modalSuccess').modal('show');
    }

    document.getElementById("iHasSuccess").value = false;
}

function showDeleteModalUnity() {

    if (domUnity.value == "") {
        document.getElementById("msgError").innerHTML = "Insira a unidade que deseja excluir.";
        $('#modalError').modal('show');
        return;
    }
    else {

        document.getElementById("btnConfirmDelete").style.display = 'inline';
        document.getElementById("btnConfirmChange").style.display = 'none';
        document.getElementById("question").innerHTML = "Deseja excluir unidade?";
        $('#confirmModal').modal('show');
        return;
    }

}


initUnityDOM();