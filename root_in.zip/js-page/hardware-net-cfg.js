﻿const domBtnSave = document.getElementById("btnSave");
const domWebIP = document.getElementById("webIP");
const domLocalIP = document.getElementById("localIP");
const domLocalMask = document.getElementById("localMask");
const domGateway = document.getElementById("gateway");
const domLocalIPSec = document.getElementById("localIPSec");
const domLocalMaskSec = document.getElementById("LocalMaskSec");

function initHardNetCfg() {
    if (!((domBtnSave) == null)) {
        domBtnSave.addEventListener('click', saveNetCfg);
    }
}

function saveNetCfg() {
    var serverIP = domWebIP.value;
    var localIP = domLocalIP.value;
    var locakMask = domLocalMask.value;
    var gateway = domGateway.value;
    var localIPSec = domLocalIPSec.value;
    var localMaskSec = domLocalMaskSec.value;

    var url = "SaveNetCfg?serverIp=" + serverIP + "&localIP=" + localIP + "&locakMask=" + locakMask + "&gateway=" + gateway +
        "&localIPSec=" + localIPSec + "&localMaskSec=" + localMaskSec;

    $.get(url, function (data, status) {
        if (data == "success") {
            document.getElementById("pReturn").innerHTML = "Configurações gravadas com sucesso."
            $('#confirmModal').modal('show');
        }
    });
}

initHardNetCfg();