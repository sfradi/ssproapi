﻿const st = document.getElementById("st");
var d = new Date();
var unixtime = d.getTime();

function initDOMCam1() {
    setUserAgent(window, "Android");
    setInterval(function () { getCam(); }, 250);
}

function getCam() {
    unixtime = unixtime + 100;

    sleep(100).then(() => {
        $.get("GetImage?unixtime=" + unixtime + "&cam=1" + "&sessionToken=" + st.value, function (data) {
            document.getElementById("imgcam1").src = "data:image/png;base64," + data;
        });
    });
    sleep(100).then(() => {
        $.get("GetImage?unixtime=" + unixtime + "&cam=2" + "&sessionToken=" + st.value, function (data) {
            document.getElementById("imgcam2").src = "data:image/png;base64," + data;
        });
    });
    sleep(100).then(() => {
        $.get("GetImage?unixtime=" + unixtime + "&cam=3" + "&sessionToken=" + st.value, function (data) {
            document.getElementById("imgcam3").src = "data:image/png;base64," + data;
        });
    });
    sleep(100).then(() => {
        $.get("GetImage?unixtime=" + unixtime + "&cam=4" + "&sessionToken=" + st.value, function (data) {
            document.getElementById("imgcam4").src = "data:image/png;base64," + data;
        });
    });
    sleep(100).then(() => {
        $.get("GetImage?unixtime=" + unixtime + "&cam=5" + "&sessionToken=" + st.value, function (data) {
            document.getElementById("imgcam5").src = "data:image/png;base64," + data;
        });
    });
    sleep(100).then(() => {
        $.get("GetImage?unixtime=" + unixtime + "&cam=6" + "&sessionToken=" + st.value, function (data) {
            document.getElementById("imgcam6").src = "data:image/png;base64," + data;
        });
    });
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function setUserAgent(window, userAgent) {
    // Works on Firefox, Chrome, Opera and IE9+
    if (navigator.__defineGetter__) {
        navigator.__defineGetter__('userAgent', function () {
            return userAgent;
        });
    } else if (Object.defineProperty) {
        Object.defineProperty(navigator, 'userAgent', {
            get: function () {
                return userAgent;
            }
        });
    }
    // Works on Safari
    if (window.navigator.userAgent !== userAgent) {
        var userAgentProp = {
            get: function () {
                return userAgent;
            }
        };
        try {
            Object.defineProperty(window.navigator, 'userAgent', userAgentProp);
        } catch (e) {
            window.navigator = Object.create(navigator, {
                userAgent: userAgentProp
            });
        }
    }
}

initDOMCam1();