﻿/*
*  Copyright (c) 2015 The WebRTC project authors. All Rights Reserved.
*
*  Use of this source code is governed by a BSD-style license
*  that can be found in the LICENSE file in the root of the source
*  tree.
*/
'use strict';

// Put variables in global scope to make them available to the browser console.
const constraints = window.constraints = {
    audio: false,
    video: true,

};

function handleSuccess(stream) {
    const video = document.querySelector('video');
    //const video = document.getElementById('video');
    const videoTracks = stream.getVideoTracks();

    //var a = navigator.mediaDevices.enumerateDevices();


    console.log('Got stream with constraints:', constraints);
    console.log(`Using video device: ${videoTracks[0].label}`);
    window.stream = stream; // make variable available to browser console
    video.srcObject = stream;
}

function restart() {
    document.getElementById('imgDocumentFront').style.display = 'none';
    document.querySelector('#gum-local').style.display = 'inline';
}

function handleError(error) {
    if (error.name === 'ConstraintNotSatisfiedError') {
        let v = constraints.video;
        errorMsg(`The resolution ${v.width.exact}x${v.height.exact} px is not supported by your device.`);
    } else if (error.name === 'PermissionDeniedError') {
        errorMsg('Permissions have not been granted to use your camera and ' +
            'microphone, you need to allow the page access to your devices in ' +
            'order for the demo to work.');
    }
    errorMsg(`getUserMedia error: ${error.name}`, error);
}

function errorMsg(msg, error) {
    const errorElement = document.querySelector('#errorMsg');
    //errorElement.innerHTML += `<p>${msg}</p>`;
    if (typeof error !== 'undefined') {
        console.error(error);
    }
}

async function init(e) {
    try {
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        handleSuccess(stream);
        e.target.disabled = true;
    } catch (e) {
        handleError(e);
    }
}

async function initCamera(type) {
    try {

        var _constraints;
        var stream = await navigator.mediaDevices.getUserMedia(constraints);;
        handleSuccess(stream);

        const stream2 = await navigator.mediaDevices.enumerateDevices();

        if (type == 'documents') {

            if (stream2[0].kind === 'videoinput') {

                var label = stream2[2].label;
                var _deviceId = stream2[2].deviceId;

                if (stream2[0].label.includes('back') || stream2[0].label.includes('BACK') || stream2[0].label.includes('Back') ||
                    stream2[0].label.includes('rear') || stream2[0].label.includes('Rear') || stream2[0].label.includes('REAR') ||
                    stream2[0].label.includes('traseira') || stream2[0].label.includes('Traseira') || stream2[0].label.includes('TRASEIRA') ||
                    stream2[0].label.includes('tras') || stream2[0].label.includes('Tras') || stream2[0].label.includes('TRAS') ||
                    stream2[0].label.includes('trás') || stream2[0].label.includes('Trás') || stream2[0].label.includes('TRÁS') || stream2[0].label.includes('EasyCamera')) {

                    constraints = {
                        video: { deviceId: _deviceId }
                    };

                    if (window.stream) {
                        window.stream.getTracks().forEach(track => {
                            track.stop();
                        });
                    }

                    stream = await navigator.mediaDevices.getUserMedia(_constraints);
                    handleSuccess(stream);
                    e.target.disabled = true;
                    return;
                }
            }

            if (stream2[1].kind === 'videoinput') {

                var label = stream2[1].label;
                var _deviceId = stream2[1].deviceId;

                if (stream2[1].label.includes('back') || stream2[1].label.includes('BACK') || stream2[1].label.includes('Back') ||
                    stream2[1].label.includes('rear') || stream2[1].label.includes('Rear') || stream2[1].label.includes('REAR') ||
                    stream2[1].label.includes('traseira') || stream2[1].label.includes('Traseira') || stream2[1].label.includes('TRASEIRA') ||
                    stream2[1].label.includes('tras') || stream2[1].label.includes('Tras') || stream2[1].label.includes('TRAS') ||
                    stream2[1].label.includes('trás') || stream2[1].label.includes('Trás') || stream2[1].label.includes('TRÁS') || stream2[1].label.includes('EasyCamera')) {

                    _constraints = {
                        video: { deviceId: _deviceId }
                    };

                    if (window.stream) {
                        window.stream.getTracks().forEach(track => {
                            track.stop();
                        });
                    }

                    stream = await navigator.mediaDevices.getUserMedia(_constraints);
                    handleSuccess(stream);
                    e.target.disabled = true;
                    return;
                }
            }

            if (stream2[2].kind === 'videoinput') {

                var label = stream2[2].label;
                var _deviceId = stream2[2].deviceId;

                if (stream2[2].label.includes('back') || stream2[2].label.includes('BACK') || stream2[2].label.includes('Back') ||
                    stream2[2].label.includes('rear') || stream2[2].label.includes('Rear') || stream2[2].label.includes('REAR') ||
                    stream2[2].label.includes('traseira') || stream2[2].label.includes('Traseira') || stream2[2].label.includes('TRASEIRA') ||
                    stream2[2].label.includes('tras') || stream2[2].label.includes('Tras') || stream2[2].label.includes('TRAS') ||
                    stream2[2].label.includes('trás') || stream2[2].label.includes('Trás') || stream2[2].label.includes('TRÁS') || stream2[2].label.includes('EasyCamera')) {

                    _constraints = {
                        video: { deviceId: _deviceId }
                    };

                    if (window.stream) {
                        window.stream.getTracks().forEach(track => {
                            track.stop();
                        });
                    }

                    stream = await navigator.mediaDevices.getUserMedia(_constraints);
                    handleSuccess(stream);
                    e.target.disabled = true;
                    return;
                }
            }

            if (stream2[3].kind === 'videoinput') {

                var label = stream2[3].label;
                var _deviceId = stream2[3].deviceId;

                if (stream2[3].label.includes('back') || stream2[3].label.includes('BACK') || stream2[3].label.includes('Back') ||
                    stream2[3].label.includes('rear') || stream2[3].label.includes('Rear') || stream2[3].label.includes('REAR') ||
                    stream2[3].label.includes('traseira') || stream2[3].label.includes('Traseira') || stream2[3].label.includes('TRASEIRA') ||
                    stream2[3].label.includes('tras') || stream2[3].label.includes('Tras') || stream2[3].label.includes('TRAS') ||
                    stream2[3].label.includes('trás') || stream2[3].label.includes('Trás') || stream2[3].label.includes('TRÁS')) {

                    _constraints = {
                        video: { deviceId: _deviceId }
                    };

                    if (window.stream) {
                        window.stream.getTracks().forEach(track => {
                            track.stop();
                        });
                    }

                    stream = await navigator.mediaDevices.getUserMedia(_constraints);
                    handleSuccess(stream);
                    e.target.disabled = true;
                    return;
                }
            }

            if (stream2[4].kind === 'videoinput') {

                var label = stream2[4].label;
                var _deviceId = stream2[4].deviceId;

                if (stream2[4].label.includes("back") || stream2[4].label.includes('BACK') || stream2[4].label.includes('Back') ||
                    stream2[4].label.includes('rear') || stream2[4].label.includes('Rear') || stream2[4].label.includes('REAR') ||
                    stream2[4].label.includes('traseira') || stream2[4].label.includes('Traseira') || stream2[4].label.includes('TRASEIRA') ||
                    stream2[4].label.includes('tras') || stream2[4].label.includes('Tras') || stream2[4].label.includes('TRAS') ||
                    stream2[4].label.includes('trás') || stream2[4].label.includes('Trás') || stream2[4].label.includes('TRÁS')) {

                    _constraints = {
                        video: { deviceId: _deviceId }
                    };

                    if (window.stream) {
                        window.stream.getTracks().forEach(track => {
                            track.stop();
                        });
                    }

                    stream = await navigator.mediaDevices.getUserMedia(_constraints);
                    handleSuccess(stream);
                    e.target.disabled = true;
                    return;
                }

                if (stream2[5].kind === 'videoinput') {

                    var label = stream2[5].label;
                    var _deviceId = stream2[5].deviceId;

                    if (stream2[5].label.includes('back') || stream2[5].label.includes('BACK') || stream2[5].label.includes('Back') ||
                        stream2[5].label.includes('rear') || stream2[5].label.includes('Rear') || stream2[5].label.includes('REAR') ||
                        stream2[5].label.includes('traseira') || stream2[5].label.includes('Traseira') || stream2[5].label.includes('TRASEIRA') ||
                        stream2[5].label.includes('tras') || stream2[5].label.includes('Tras') || stream2[5].label.includes('TRAS') ||
                        stream2[5].label.includes('trás') || stream2[5].label.includes('Trás') || stream2[5].label.includes('TRÁS') || stream2[5].label.includes('EasyCamera')) {

                        _constraints = {
                            video: { deviceId: _deviceId }
                        };

                        if (window.stream) {
                            window.stream.getTracks().forEach(track => {
                                track.stop();
                            });
                        }

                        stream = await navigator.mediaDevices.getUserMedia(_constraints);
                        handleSuccess(stream);
                        e.target.disabled = true;
                        return;
                    }
                }

                if (stream2[6].kind === 'videoinput') {

                    var label = stream2[6].label;
                    var _deviceId = stream2[6].deviceId;

                    if (stream2[6].label.includes('back') || stream2[6].label.includes('BACK') || stream2[6].label.includes('Back') ||
                        stream2[6].label.includes('rear') || stream2[6].label.includes('Rear') || stream2[6].label.includes('REAR') ||
                        stream2[6].label.includes('traseira') || stream2[6].label.includes('Traseira') || stream2[6].label.includes('TRASEIRA') ||
                        stream2[6].label.includes('tras') || stream2[6].label.includes('Tras') || stream2[6].label.includes('TRAS') ||
                        stream2[6].label.includes('trás') || stream2[6].label.includes('Trás') || stream2[6].label.includes('TRÁS') || stream2[6].label.includes('EasyCamera')) {

                        _constraints = {
                            video: { deviceId: _deviceId }
                        };

                        if (window.stream) {
                            window.stream.getTracks().forEach(track => {
                                track.stop();
                            });
                        }

                        stream = await navigator.mediaDevices.getUserMedia(_constraints);
                        handleSuccess(stream);
                        e.target.disabled = true;
                        return;
                    }


                    if (stream2[7].kind === 'videoinput') {

                        var label = stream2[7].label;
                        var _deviceId = stream2[7].deviceId;

                        if (stream2[7].label.includes('back') || stream2[7].label.includes('BACK') || stream2[7].label.includes('Back') ||
                            stream2[7].label.includes('rear') || stream2[7].label.includes('Rear') || stream2[7].label.includes('REAR') ||
                            stream2[7].label.includes('traseira') || stream2[7].label.includes('Traseira') || stream2[7].label.includes('TRASEIRA') ||
                            stream2[7].label.includes('tras') || stream2[7].label.includes('Tras') || stream2[7].label.includes('TRAS') ||
                            stream2[7].label.includes('trás') || stream2[7].label.includes('Trás') || stream2[7].label.includes('TRÁS') || stream2[7].label.includes('EasyCamera')) {

                            _constraints = {
                                video: { deviceId: _deviceId }
                            };

                            if (window.stream) {
                                window.stream.getTracks().forEach(track => {
                                    track.stop();
                                });
                            }

                            stream = await navigator.mediaDevices.getUserMedia(_constraints);
                            handleSuccess(stream);
                            e.target.disabled = true;
                            return;
                        }
                    }
                }

                if (stream2[8].kind === 'videoinput') {

                    var label = stream2[8].label;
                    var _deviceId = stream2[8].deviceId;

                    if (stream2[8].label.includes('back') || stream2[8].label.includes('BACK') || stream2[8].label.includes('Back') ||
                        stream2[8].label.includes('rear') || stream2[8].label.includes('Rear') || stream2[8].label.includes('REAR') ||
                        stream2[8].label.includes('traseira') || stream2[8].label.includes('Traseira') || stream2[8].label.includes('TRASEIRA') ||
                        stream2[8].label.includes('tras') || stream2[8].label.includes('Tras') || stream2[8].label.includes('TRAS') ||
                        stream2[8].label.includes('trás') || stream2[8].label.includes('Trás') || stream2[8].label.includes('TRÁS') || stream2[8].label.includes('EasyCamera')) {

                        _constraints = {
                            video: { deviceId: _deviceId }
                        };

                        if (window.stream) {
                            window.stream.getTracks().forEach(track => {
                                track.stop();
                            });
                        }

                        stream = await navigator.mediaDevices.getUserMedia(_constraints);
                        handleSuccess(stream);
                        e.target.disabled = true;
                        return;
                    }
                }


                if (stream2[9].kind === 'videoinput') {

                    var label = stream2[9].label;
                    var _deviceId = stream2[9].deviceId;

                    var _deviceId = stream2[3].deviceId;
                    if (stream2[9].label.includes('back') || stream2[9].label.includes('BACK') || stream2[9].label.includes('Back') ||
                        stream2[9].label.includes('rear') || stream2[9].label.includes('Rear') || stream2[9].label.includes('REAR') ||
                        stream2[9].label.includes('traseira') || stream2[9].label.includes('Traseira') || stream2[9].label.includes('TRASEIRA') ||
                        stream2[9].label.includes('tras') || stream2[9].label.includes('Tras') || stream2[9].label.includes('TRAS') ||
                        stream2[9].label.includes('trás') || stream2[9].label.includes('Trás') || stream2[9].label.includes('TRÁS') || stream2[9].label.includes('EasyCamera')) {

                        _constraints = {
                            video: { deviceId: _deviceId }
                        };

                        if (window.stream) {
                            window.stream.getTracks().forEach(track => {
                                track.stop();
                            });
                        }

                        stream = await navigator.mediaDevices.getUserMedia(_constraints);
                        handleSuccess(stream);
                        e.target.disabled = true;
                        return;
                    }
                }

                if (stream2[10].kind === 'videoinput') {

                    var label = stream2[10].label;
                    var _deviceId = stream2[10].deviceId;

                    if (stream2[10].label.includes('back') || stream2[10].label.includes('BACK') || stream2[10].label.includes('Back') ||
                        stream2[10].label.includes('rear') || stream2[10].label.includes('Rear') || stream2[10].label.includes('REAR') ||
                        stream2[10].label.includes('traseira') || stream2[10].label.includes('Traseira') || stream2[10].label.includes('TRASEIRA') ||
                        stream2[10].label.includes('tras') || stream2[10].label.includes('Tras') || stream2[10].label.includes('TRAS') ||
                        stream2[10].label.includes('trás') || stream2[10].label.includes('Trás') || stream2[10].label.includes('TRÁS') || stream2[10].label.includes('EasyCamera')) {

                        _constraints = {
                            video: { deviceId: _deviceId }
                        };

                        if (window.stream) {
                            window.stream.getTracks().forEach(track => {
                                track.stop();
                            });
                        }

                        stream = await navigator.mediaDevices.getUserMedia(_constraints);
                        handleSuccess(stream);
                        e.target.disabled = true;
                        return;
                    }
                }
            }


            var stream = await navigator.mediaDevices.getUserMedia(constraints);
            handleSuccess(stream);
            e.target.disabled = true;

        }
        else {
            alert('selfie capture');
            var stream = await navigator.mediaDevices.getUserMedia(constraints);
            handleSuccess(stream);
            e.target.disabled = true;
        }

        //const stream = await stream2[0].getUserMedia(constraints);
        //handleSuccess(stream);
        // e.target.disabled = true;
    } catch (e) {
        handleError(e);
    }

}

function openCameraTest() {
    setTimeout(function () { return window.location = 'simulacao\TestWebRTC?accessToken=' + token + '&nowebcam=' + token; }, 100);
}

function initCameraSelfie() {
    initCamera();
}

function initCameraDocuments() {
    initCamera("documents");    
}

//document.querySelector('#showVideo').addEventListener('click', e => init(e));
//initCamera();

initCameraDocuments();
