﻿const domBtnSave = document.getElementById("btnSave");
const domServerIP = document.getElementById("serverIP");
const domAlexasDomain = document.getElementById("alexasDomain");
const domAlexasId = document.getElementById("alexasId");
const domAlexasEnabled = document.getElementById("alexasEnabled");
function initNetCfg() {
    if (!((domBtnSave) == null)) {
        domBtnSave.addEventListener('click', saveNetCfg);
    }

    if (!domAlexasEnabled.value) {
        domAlexasEnabled.checked = true;
    }
}
function saveNetCfg() {
    var serverIP = domServerIP.value;
    var alexasDomain = domAlexasDomain.value;
    var alexasId = domAlexasId.value;
    var alexasEnabled = domAlexasEnabled.checked == true ? true : false; 

    var url = "SaveNetCfg?serverIp=" + serverIP + "&AlexasEnabled=" + alexasEnabled +"&AlexasDomain=" + alexasDomain + "&AlexasId=" + alexasId;

    $.get(url, function (data, status) {
        if (data == "success") {
            document.getElementById("pReturn").innerHTML = "Configurações gravadas com sucesso."
            $('#confirmModal').modal('show');
        }
    });
}
initNetCfg();