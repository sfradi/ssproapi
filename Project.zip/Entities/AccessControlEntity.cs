﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Entities
{
    public class AccessControlEntity
    {
        public partial class Actions
        {
            public long Id { get; set; }
            public int Type { get; set; }

            public string Description { get; set; }
            public int PanelPosition { get; set; }
            public string BtnLabel1 { get; set; }
            public string BtnLabel2 { get; set; }
            public int Btn1DeviceId { get; set; }
            public int Btn2DeviceId { get; set; }
            public bool Btn1Active { get; set; }
            public bool Btn2Active { get; set; }
            public int CameraId { get; set; }
            public int AccountId { get; set; }
            public int BotId { get; set; }
            public bool IsActive { get; set; }
        }

        public partial class Devices
        {
            public long Id { get; set; }
            public string Description { get; set; }
            public int Type { get; set; }
            public int Model { get; set; }
            public string IP { get; set; }
            public int Port { get; set; }
            public int DeviceId { get; set; }
            public int DeviceOut { get; set; }
            public int DeviceModule { get; set; }
            public string Url { get; set; }
            public string JsonCFG { get; set; }
            public int AccountId { get; set; }
            public int BotId { get; set; }
            public bool IsActive { get; set; }
        }

    }
}
