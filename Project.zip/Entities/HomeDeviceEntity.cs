﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Entities
{
    public class HomeDeviceEntity
    {

        public int DeviceId { get; set; }

        public int Status { get; set; }

        public string DeviceIP { get; set; }

        public List<HomeDeviceRelays> DeviceRelays { get; set; }

        public partial class HomeDeviceRelays
        {            
                /// <summary>
                /// The number of relay on the board. The number of relays is Zero based
                /// </summary>
                public int RelayId { get; set; }
                /// <summary>
                /// Defines if relay is Pulse or Retention
                /// </summary>
                public int Type { get; set; }

                /// <summary>
                /// Defines the timer of status relay. If Timer = 0, always as retention
                /// </summary>
                public long Timer { get; set; }

                /// <summary>
                /// Defines if relay is HIGH or LOW
                /// </summary>
                public int Status { get; set; }
           

        }

    }
}
