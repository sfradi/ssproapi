﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Entities
{
    public class HardwareCfg
    {
        public string DefaultServerIP { get; set; }

        public string ServerIP { get; set; }

        public string LocalIP { get; set; }

        public string LocalMask { get; set; }

        public string Gateway { get; set; }

        public  string LocalIPSec { get; set; }

        public string LocalMaskSec { get; set; }
    }
}
