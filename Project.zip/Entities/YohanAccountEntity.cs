﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Entities
{
    public class YohanAccountEntity
    {
        public long Id { get; set; }
        public long AccountId { get; set; }
        public string RegUser { get; set; }
        public string RegPass { get; set; }
        public string RegDomain { get; set; }
        public string Description { get; set; }
        public int ToneTime { get; set; }
        public int SystemTypeId { get; set; }
        public bool IsActive { get; set; }
        public int SipPort { get; set; }
        public int ServiceId { get; set; }
        public string CallCenterNumber { get; set; }
    }
}
