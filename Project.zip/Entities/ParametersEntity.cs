﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portal.SSPRO.Entities
{
    public class ParametersEntity
    {

        public long id { get; set; }

        public long AccountId { get; set; }

        public string ParamName { get; set; }

        /// <summary>
        /// Parameters in JSON format for all items
        /// </summary>
        public string DataParam { get; set; }

        public int ProductId { get; set; }

        public int Status { get; set; }

    }
}
