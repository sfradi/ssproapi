﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Entities
{
    public class HomeNetCfg
    {
        public string ServerIP { get; set; }

        public bool AlexasEnabled { get; set; }

        public string AlexasDomain { get; set; }

        public string AlexasId { get; set; }
    }
}
