﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Entities
{
    public class SharedInfoEntity
    {

        public partial class ProductsDatabaseAvailable
        {
            public long Id { get; set; }
            public int ProductTypeId { get; set; }
            public string DbName { get; set; }
            public string DbDataSource { get; set; }
            public string DbUID { get; set; }
            public string DbPwd { get; set; }
            public string DbType { get; set; }
            public int ServicesCounter { get; set; }
            public int ServicesLimit { get; set; }
            public bool IsActive { get; set; }
        }

        public partial class ProductIdDBRelationship
        {
            public long Id { get; set; }
            public int DBId { get; set; }
            public int ProductId { get; set; }
            public bool IsActive { get; set; }
        }

    }
}
