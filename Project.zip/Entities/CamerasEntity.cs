﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Entities
{
    public class CamerasEntity
    {
        public long Id { get; set; }
        public int CameraType { get; set; }
        public string Description { get; set; }
        public string Url { get; set; }
        public string User { get; set; }
        public string Password { get; set; }
        public int AccountId { get; set; }
        public int BotId { get; set; }
        public bool IsActive { get; set; }
    }
}
