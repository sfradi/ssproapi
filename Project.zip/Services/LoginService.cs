﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Repositories;
using SSPRO.Web.Models;
using SSPRO.Web.Controllers;
using SSPRO.Web.Cache;
using Microsoft.Extensions.Caching.Memory;
using SSPRO.Web.Interfaces;

namespace SSPRO.Web.Services
{
    public class LoginService
    {
        IMemoryCache _memoryCache;
        Microsoft.Extensions.Options.IOptions<MemoryCacheOptions> _options;
        LoginRepository _loginRepository;
        LoginCached _loginCached;
        SharedParametersService _shdParametersService;
        
        public LoginService(IMemoryCache memoryCache)
        {            
            _memoryCache = memoryCache;
            _loginRepository = new LoginRepository(_memoryCache);
            _loginCached = new LoginCached(_memoryCache);
            _shdParametersService = new SharedParametersService(_memoryCache);
             
        }

        public LoginModel GetLoginInfo(string userName, string pwd, string sessionToken)
        {
            LoginModel _login = new LoginModel();

            var userInfo = _loginRepository.GetLoginInfo(userName);

            if (userInfo == null)
            {
                throw new Exception("Login não localizado no banco de dados");
            }

            _login = new LoginModel()
            {                
                SessionToken = sessionToken,
                AccessGroup = userInfo.AccessGroup,
                AccountId = userInfo.AccountId,
                AuthKey = userInfo.AuthKey,
                CelPhone = userInfo.CelPhone,
                email = userInfo.email,
                id = userInfo.id,
                Name = userInfo.Name,
                Password = userInfo.Password,
                ProductId = userInfo.ProductId,
                ProfileImage64 = userInfo.ProfileImage64,
                RememberKey = userInfo.RememberKey,
                Result = userInfo.Result,
                Status = userInfo.Status,
                Type = userInfo.Type,
                Unity = userInfo.Unity,
                UserName = userInfo.UserName,
            };


            if (userInfo.UserName == userName && userInfo.Password == pwd) 
            {
                _loginCached.SetLoginCache(_login);
                _shdParametersService.SetSharedParameters(_login.AccountId, _login.ProductId, _login.SessionToken, _login.Type);
               
                return _login;
            }           

            return _login;
        }

    }
}
