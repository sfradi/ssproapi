﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Cache;
using SSPRO.Web.Repositories;

namespace SSPRO.Web.Services
{
    public class SharedParametersService
    {
        SharedParametersRepository _sharedParameters;
        SharedParametersCached _parametersCached;

        public SharedParametersService(IMemoryCache memoryCache)
        {
            _sharedParameters = new SharedParametersRepository(memoryCache);
            _parametersCached = new SharedParametersCached(memoryCache);
        }

        public void SetSharedParameters(long accountId, long productId, string sessionToken, int loginType)
        {
            var shdParams = _sharedParameters.GetParameters(accountId, productId, loginType);
            _parametersCached.SetSharedParamCache(shdParams, sessionToken);
        }

    }
}
