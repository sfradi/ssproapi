﻿using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using SSPRO.Web.Cache;
using SSPRO.Web.Interfaces;
using SSPRO.Web.Models;

namespace SSPRO.Web.Services
{
    public class MainService : IMainService
    {
        IMemoryCache _memorycache;
        IdentifiersCached _identifiersCached;

        public MainService(IMemoryCache memorycache)
        {
            _memorycache = memorycache;
            _identifiersCached = new IdentifiersCached(_memorycache);
        }

        public void StartDataList()
        {
            //var cardList = GetListOfCards();
            //_identifiersCached.SetCards(cardList);
        }

        public List<IdentifiersModel.Cards> GetCardList()
        {          
            return _identifiersCached.GetCards();
        }


        private List<IdentifiersModel.Cards> GetListOfCards()
        {
            var jsonText = System.IO.File.ReadAllText(@"C:\Data\Users\DefaultAccount\Documents\JDB\cards.json");
            var cards = JsonConvert.DeserializeObject<IList<IdentifiersModel.Cards>>(jsonText);
            return cards.ToList();
        }



    }
}
