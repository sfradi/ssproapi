﻿using Microsoft.CodeAnalysis.Diagnostics;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Controllers;
using SSPRO.Web.Entities;
using SSPRO.Web.Helpers;
using SSPRO.Web.Models;
using SSPRO.Web.Repositories;
using ZXing.QrCode.Internal;
 

namespace SSPRO.Web.Services
{
    public class AccountService
    {
        AccountRepository _accountRepository;

        public AccountService(IMemoryCache memoryCache)
        {
            _accountRepository = new AccountRepository(memoryCache);
        }

        public List<AccountModel> GetAllAccountInfo(LoginModel model)
        {
            List<AccountModel> list = new List<AccountModel>();

            var result = new List<SSPRO.Web.Entities.AccountEntity>();

            switch (model.Type)
            {
                case 1:
                    result = _accountRepository.GetAllAccountInfo();
                    break;
                case 2:
                    result = _accountRepository.GetAllAccountInfo((int)model.AccountId);
                    break;
                case 3:
                    result = _accountRepository.GetAllAccountInfo((int)model.AccountId);
                    break;
            }

            foreach (var i in result)
            {
                list.Add(new AccountModel
                {
                    Id = i.Id,
                    Address = i.Address,
                    BotsCount = i.BotsCount,
                    CelPhone = i.CelPhone,
                    City = i.City,
                    Contact = i.Contact,
                    CPFCNPJ = i.CPFCNPJ,
                    CreateDate = i.CreateDate,
                    Email = i.Email,
                    IsActive = i.IsActive,
                    ModifiedDate = i.ModifiedDate,
                    Name = i.Name,
                    Neighborhood = i.Neighborhood,
                    Number = i.Number,
                    Phone = i.Phone,
                    State = i.State,
                    Status = i.Status,
                    TermOfResponsability = i.TermOfResponsability,
                    ZipCode = i.ZipCode,

                });
            }

            return list;

        }

        public AccountModel GetAccountInfo(long accountId)
        {
            try
            {
                var result = _accountRepository.GetAccountInfo(accountId);

                AccountModel model = new AccountModel()
                {
                    Id = result.Id,
                    Name = result.Name,
                    Address = result.Address,
                    BotsCount = result.BotsCount,
                    CelPhone = result.CelPhone,
                    City = result.City,
                    Contact = result.Contact,
                    CPFCNPJ = result.CPFCNPJ,
                    CreateDate = result.CreateDate,
                    Email = result.Email,
                    IsActive = result.IsActive,
                    ModifiedDate = result.ModifiedDate,
                    Neighborhood = result.Neighborhood,
                    Number = result.Number,
                    Phone = result.Phone,
                    State = result.State,
                    Status = result.Status,
                    TermOfResponsability = result.TermOfResponsability,
                    ZipCode = result.ZipCode,
                };

                return model;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string InsertAccount(AccountModel model)
        {
            AccountEntity accountEntity = new AccountEntity()
            {                
                Address = model.Address,
                BotsCount = 0,
                CelPhone = model.CelPhone.OnlyNumbers(),
                City = model.City,
                Contact = "",
                CPFCNPJ = model.CPFCNPJ.OnlyNumbers(),
                Email = model.Email,
                IsActive = true,
                ModifiedDate = DateTime.Now,
                Name = model.Name,
                Neighborhood = model.Neighborhood,
                Number = model.Number,
                Phone = model.Phone.OnlyNumbers(),
                State = model.State,
                Status = model.Status,
                TermOfResponsability = "",
                ZipCode = model.ZipCode,
            };

            var result = _accountRepository.InsertAccount(accountEntity);

            if (result)
            {
                return "success";
            }
            else
            {
                return "fail";
            }

        }


        public string UpdateAccount(AccountModel model)
        {
            AccountEntity accountEntity = new AccountEntity()
            {
                Id = model.Id,
                Address = model.Address,
                BotsCount = 0,
                CelPhone = model.CelPhone.OnlyNumbers(),
                City = model.City,
                Contact = "",
                CPFCNPJ = model.CPFCNPJ.OnlyNumbers(),
                Email = model.Email,
                IsActive = true,
                ModifiedDate = DateTime.Now,
                Name = model.Name,
                Neighborhood = model.Neighborhood,
                Number = model.Number,
                Phone = model.Phone.OnlyNumbers(),
                State = model.State,
                Status = model.Status,
                TermOfResponsability = "",
                ZipCode = model.ZipCode,
            };

            var result = _accountRepository.UpdateAccount(accountEntity);

            if (result)
            {
                return "success";
            } 
            else
            {
                return "fail";
            }

        }

    }
}
