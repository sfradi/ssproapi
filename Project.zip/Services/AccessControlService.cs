﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Entities;
using SSPRO.Web.Models;
using SSPRO.Web.Repositories;
using ZXing.QrCode.Internal;

namespace SSPRO.Web.Services
{
    public class AccessControlService
    {
        AccessControlRepository _accessControlRepository;
       
        public AccessControlService(IMemoryCache memoryCache)
        {
            _accessControlRepository = new AccessControlRepository(memoryCache);
            
        }
         
    }
}
