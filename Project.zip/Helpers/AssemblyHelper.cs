﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portal.SSPRO.Helpers
{
    public static class AssemblyHelper
    {

        public static string GetAssemblyVersion()
        {
            //Type t = typeof(Portal.SSPRO.Program);

            var version = "";// System.Reflection.Assembly.GetAssembly(t).GetName().Version;

            return version.ToString();
        }


    }
}
