﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SSPRO.Web.Helpers
{
    public static class FormatHelper
    {        
        public static string OnlyNumbers(this string str)
        {
            var digits = new Regex(@"[^\d]");
            return digits.Replace(str,"");
        }

        

    }
}
