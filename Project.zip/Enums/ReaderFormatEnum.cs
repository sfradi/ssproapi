﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Enums
{
    public enum ReaderFormat : int
    {

        WIEGAND26 = 1,

        WIEGAND32 = 2,

        WIEGAND34 = 2,

        WIEGAND35 = 3,

        WIEGAND66 = 4,

    }
}
