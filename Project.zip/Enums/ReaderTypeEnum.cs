﻿
namespace SSPRO.Web
{
    public enum ReaderType : int
    {
        TX = 1,
        
        Reserved = 2,
        
        Card = 3,
        
        Reserved2 = 4,
        
        Finger = 5,

        PassiveTAG = 6,
    }
}
