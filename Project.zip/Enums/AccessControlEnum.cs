﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Enums
{
    public enum AccessControlEnum
    {
        [Description("SS PRO")]
        SSPRO = 1,

        [Description("CONTROL ID")]
        CONTROLID = 2,

        [Description("MÓDULO GUARITA")]
        MODULO_GUARITA = 3,

        [Description("PLACA ETHERNET")]
        PLACA_ETHERNET = 4,

        [Description("ANVIZ")]
        ANVIZ = 5,

        [Description("API REST")]
        API_REST = 6,
    }
}
