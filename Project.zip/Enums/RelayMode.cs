﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Enums
{
    public enum RelayMode : int
    {

        PerSecond = 1,

        Pulse = 2,          

        SolidState = 3,

    }
}
