﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Enums
{
    public enum UserTypeEnum : int
    {
        [Description("Administrador")]
        Administrador = 1,

    }
}
