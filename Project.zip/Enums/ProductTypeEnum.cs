﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Enums
{
    public enum ProductTypeEnum : int
    {

        SSPRO_Web = 4,
    }
}
