﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Enums
{
    public enum CameraTypeEnum : int
    { 
        [Description("D-Guard Center")]
        DGuard = 1,

        [Description("DVR Intelbras")]
        DvrIntelbras = 2,

        [Description("Camera IP Intelbras Serie VIP S")]
        IPIntelbrasSerieS = 3,
 
    }
}
