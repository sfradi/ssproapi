﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Enums
{
    public enum SensorType :int
    {
        Normal_Close = 1,

        Normal_Open = 2,

        Safe_Box = 3,
    }
}
