﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Models;

namespace SSPRO.Web.Cache
{
    public  class IdentifiersCached
    {
        IMemoryCache _memorycache;


        public IdentifiersCached(IMemoryCache memorycache)
        {
            _memorycache = memorycache;
        }

        public void SetCards(List<IdentifiersModel.Cards> cardList)
        {
            _memorycache.Remove("Cards");
            _memorycache.Set("Cards", cardList);        
        }

        public List<IdentifiersModel.Cards> GetCards()
        {
            DeviceModel.Relays relays = new DeviceModel.Relays();
            DeviceModel deviceModel = new DeviceModel();
            deviceModel.Id = 0;

           return (List<IdentifiersModel.Cards>)_memorycache.Get("Cards");
        }


    }
}
