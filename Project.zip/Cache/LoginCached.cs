﻿using Microsoft.AspNetCore.Identity.UI.V3.Pages.Account.Internal;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Models;

namespace SSPRO.Web.Cache
{
    public class LoginCached
    {
        IMemoryCache _memorycache;

        public LoginCached(IMemoryCache memorycache)
        {           
            _memorycache = memorycache;
        }

        public void SetLoginCache(Models.LoginModel login)
        {            
            _memorycache.Set($"Login_{login.SessionToken}", login);          
        }

        public Models.LoginModel GetLoginCache(string sessionToken)
        {
            var test = _memorycache.Get<Models.LoginModel>($"Login_{sessionToken}");
            return _memorycache.Get<Models.LoginModel>($"Login_{sessionToken}");
        }



    }
}
