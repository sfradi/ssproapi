﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Entities;

namespace SSPRO.Web.Cache
{
    public class SharedParametersCached
    {
        IMemoryCache _memorycache;
        Microsoft.Extensions.Options.IOptions<MemoryCacheOptions> options;

        public SharedParametersCached(IMemoryCache memoryCache)
        {
            options = new MemoryCacheOptions();
            _memorycache = memoryCache;
        }

        public void SetSharedParamCache(List<SharedParametersEntity> sharedParameters, string sessionToken)
        {
            _memorycache.Set($"SharedParam_{sessionToken}", sharedParameters);

            var test = _memorycache.Get<List<SharedParametersEntity>>($"SharedParam_{sessionToken}");
        }

        public List<SharedParametersEntity> GetSharedParamCache(string sessiontToken)
        {
            return _memorycache.Get<List<SharedParametersEntity>>($"SharedParam_{sessiontToken}");
        }


    }
}
