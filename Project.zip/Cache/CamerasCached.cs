﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Entities;
using SSPRO.Web.Models;

namespace SSPRO.Web.Cache
{
    public class CamerasCached
    {
        IMemoryCache _memorycache;

        public CamerasCached(IMemoryCache memorycache)
        {
            _memorycache = memorycache;
        }

        public void Set(List<CamerasModel> camerasModel, string sessionToken)
        {
            _memorycache.Set($"Cameras_{sessionToken}", camerasModel);
        }

        public List<CamerasModel> Get( string sessionToken)
        {
            return (List<CamerasModel>)_memorycache.Get($"Cameras_{sessionToken}");
        }

    }
}
