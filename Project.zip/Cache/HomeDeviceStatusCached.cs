﻿using Microsoft.Extensions.Caching.Memory;
using SSPRO.Web.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Cache
{
    public class HomeDeviceStatusCached
    {

        IMemoryCache _memorycache;

        public HomeDeviceStatusCached(IMemoryCache memorycache)
        {
            _memorycache = memorycache;
        }

        public List<HomeDeviceEntity> GetDeviceStatus()
        {
            var l = _memorycache.Get<List<HomeDeviceEntity>>("HomeDeviceStatus");
            return l;
        }

        public void SetDeviceStatus(List<HomeDeviceEntity> homeDeviceEntityList)
        {
            _memorycache.Set<List<HomeDeviceEntity>>("HomeDeviceStatus", homeDeviceEntityList);
        }

    }
}
