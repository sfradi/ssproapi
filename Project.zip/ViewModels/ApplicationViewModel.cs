﻿using Portal.SSPRO.Models;
using SSPRO.Web.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Models;
using SS.Shared.BackOffice.Models.UserInformation;

namespace Portal.SSPRO.ViewModels
{
    public class ApplicationViewModel
    {
        public string SessionToken { get; set; }

        public LoginModel loginModel { get; set; } = null;

        public UserInformationModel UserInformationModel {get;set;} = null;

        public PersonModel personModel { get; set; } = null;

        public ProfileModel profileModel { get; set; } = null;

        public AccountModel accountModel { get; set; }

        public List<AccountModel> accountList { get; set; }

        public YohanAccountModel yohanAccount { get; set; }

        public List<YohanAccountModel> yohanAccountList { get; set; }

        public List<AccessControlModel.Actions> acActionList { get; set; } 

        public UnitiesModel unity { get; set; }

        public List<UnitiesModel> unitiesList {get;set;}

        public AccountAdminModel accountAdmin { get; set; } = null;

        public List<AccountAdminModel> accountAdminList { get; set; } = null;

        public UnityModel unityModel { get; set; } = null;

        public List<UnityModel> unityModels { get; set; } = null;

        public List<UserAccountModel> userAccountList { get; set; } = null;

        public UserAccountModel userAccount { get; set; } = null;

        public List<UserAccountModel.UserType> userTypeList { get; set; } = null; 

        public ErrorViewModel errorViewModel { get; set; } = null;

        public HomeNetCfg homeNetCfg { get; set; } = null;

        public HardwareCfg HardwareNetCfg { get; set; } = null;
    }
}
