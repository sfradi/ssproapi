﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Portal.SSPRO.ViewModels;
using RestSharp;
using SSPRO.Web.Cache;
using SSPRO.Web.Models;
using SSPRO.Web.Services;
using SS.Shared.BackOffice.Interfaces;
using SS.Shared.BackOffice.Services;
using SS.Shared.Authentication.Intefaces;
using SS.Shared.Authentication.Services;
using SS.Shared.Logger.Interfaces;

namespace SSPRO.Web.Controllers
{
    [Route("[controller]")]
    public class AccountController : Controller
    {
        IMemoryCache _memoryCache;
        Microsoft.Extensions.Options.IOptions<MemoryCacheOptions> _options;
        IBackOfficeService _backOfficeService;
        IAuthenticationService _authenticationService;
        AccountService _accountService;
        LoginCached _loginCached;

        public AccountController(IMemoryCache memoryCache, ILoggerService logger)
        {
            _options = new MemoryCacheOptions();
            _memoryCache = memoryCache;
            _accountService = new AccountService(_memoryCache);
            _loginCached = new LoginCached(_memoryCache);
            _backOfficeService = new BackOfficeService();
            _authenticationService = new AuthenticationService(memoryCache, logger);
        }

        public IActionResult Index(string sessionToken)
        {
            var userId = _authenticationService.GetDataInToken(sessionToken).UserName;

            var login = _backOfficeService.GetUserInformation(userId, SS.Shared.BackOffice.Enums.ProductTypeEnum.SSPRO_Web);
           
            ApplicationViewModel model = new ApplicationViewModel()
            {
                SessionToken = sessionToken,
                UserInformationModel = login,              
                accountModel = new AccountModel(),
            };

            //return View("AccountInfo", model);
            return View("_Index", model);
        }

        [HttpGet("GetAccountList")]
        public List<AccountModel> GetAccountList(string sessionToken)
        {
            var login = _loginCached.GetLoginCache(sessionToken);
            var accounts = _accountService.GetAllAccountInfo(login);
            return accounts;
        }


        [HttpGet("GetAccountById")]
        public AccountModel GetAccountById(long accountId, string sessionToken)
        {
            var userCached = _loginCached.GetLoginCache(sessionToken);

            var accountInfo = _accountService.GetAccountInfo(accountId);

            var accountModel = new Models.AccountModel()
            {
                Id = accountInfo.Id,
                Name = accountInfo.Name,
                Phone = accountInfo.Phone,
                Address = accountInfo.Address,
                CelPhone = accountInfo.CelPhone,
                City = accountInfo.City,
                Contact = accountInfo.Contact,
                CPFCNPJ = accountInfo.CPFCNPJ,
                CreateDate = accountInfo.CreateDate,
                Email = accountInfo.Email,
                ModifiedDate = accountInfo.ModifiedDate,
                Neighborhood = accountInfo.Neighborhood,
                Number = accountInfo.Number,
                State = accountInfo.State,
                Status = accountInfo.Status,
                TermOfResponsability = accountInfo.TermOfResponsability,
                ZipCode = accountInfo.ZipCode,
                IsActive = accountInfo.IsActive,
            };

            return accountModel;
        }


        [HttpGet("AddAccount")]
        public string AddAccount(AccountModel account, string sessionToken)
        {
            try
            {
                return _accountService.InsertAccount(account);
            }
            catch (Exception ex)
            {
                //TODO: ADD LOGGER
                return ex.Message;
            }
            
        }


        [HttpGet("UpdateAccount")]
        public string UpdateAccount(AccountModel account, string sessionToken)
        {
            try
            {
                return _accountService.UpdateAccount(account);
            }
            catch(Exception ex)
            {
                //TODO: ADD LOGGER
                return ex.Message;
            }
            
        }
    }
}