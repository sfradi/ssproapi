﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using SSPRO.Web.Cache;
using SSPRO.Web.Interfaces;
using SSPRO.Web.Services;

namespace SSPRO.Web.Controllers
{
    

    public class LayerController : Controller
    {
        IMemoryCache _cache;
        Microsoft.Extensions.Options.IOptions<MemoryCacheOptions> _options;
        IMainService _mainServices;

        public LayerController(IMainService mainServices)
        {
            _options = new MemoryCacheOptions();
            _cache = new MemoryCache(_options);
            _mainServices = mainServices;
        }

        public IActionResult Index()
        {
            string error = "";

            string CPU = "";  
            List<string> listOfIps = null;

            ViewBag.IP = "";
            ViewBag.Mask = ""; 
            

            return View("Index");
        }

        //[HttpGet("InterruptsPanel")]
        //public IActionResult InterruptsPanel()
        //{
        //    return View("../Layer/Index"); //return RedirectToAction("InterruptsPanel", "HomeAutomation");
        //}
    }
}