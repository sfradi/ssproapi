﻿using CryptSharp;
using Microsoft.AspNetCore.Mvc;

using Microsoft.Extensions.Caching.Memory;
using Portal.SSPRO.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Cache;
using SSPRO.Web.Services;
using SS.Shared.BackOffice.Interfaces;
using SS.Shared.Authentication.Intefaces;
using SS.Shared.Authentication.Services;
using SS.Shared.Logger.Interfaces;
using Microsoft.AspNetCore.Http;

namespace SSPRO.Web.Controllers
{
    public class Login : Controller
    {

        LoginService _loginService;
        LoginCached _loginCached;
        ILoggerService _logger;
        IAuthenticationService _authenticationService;
        IBackOfficeService _backOfficeService;

        public Login(IMemoryCache memorycache, IBackOfficeService backOfficeService, ILoggerService loggerService)
        {
            _logger = loggerService;
            _loginService = new LoginService(memorycache);
            _loginCached = new LoginCached(memorycache);
            _authenticationService = new AuthenticationService(memorycache, _logger);
            _backOfficeService = backOfficeService;

        }

        class UserModel { public string UserName { get; set; } public string Password { get; set; } }

        public async Task<IActionResult> Index(string user, string pwd)
        {       

            try
            {
                var model = new UserModel { UserName = "sfradi", Password = "12345" };
        
                try
                {
                    if (string.IsNullOrEmpty(model.UserName) || string.IsNullOrEmpty(model.Password))
                    {
                        _logger.AddWarning($"Usuário ou Senha não informados.", new Exception($"User or Password is Null."));
                        return await Task.FromResult(this.Unauthorized($"Usuário ou Senha não informados."));
                    }

                    _logger.AddDebug($"Requested Login by: {model.UserName}");

                    var token = _authenticationService.Authorization(model.UserName, model.Password, 5);

                    if (token.Authorized && !string.IsNullOrEmpty(token.AccessToken))
                    {
                        _logger.AddDebug($"Authorized Login To: {model.UserName}");
                        return RedirectToAction("Index", "Account", new { sessionToken = token.AccessToken });
                    }

                    _logger.AddWarning($"Login não autorizado para: {model.UserName}", new Exception($"Unauthorized login to: {model.UserName}"));
                    return await Task.FromResult(this.Unauthorized(null));
                }
                catch (Exception ex)
                {
                    var msgError = $"{ex.Message} -> InternalServerError: {StatusCodes.Status500InternalServerError.ToString()}. Error: {ex.Message}";

                    _logger.AddError(msgError, ex);
                    ApplicationViewModel _model = new ApplicationViewModel()
                    {
                        errorViewModel = new Portal.SSPRO.Models.ErrorViewModel()
                        {
                            HasError = true,
                            MsgError = "Usuário não localizado.",
                            RequestId = user,
                        },

                    };

                    return View("Error", _model);
                }


            }
            catch (Exception ex)
            {
                ApplicationViewModel model = new ApplicationViewModel()
                {
                    errorViewModel = new Portal.SSPRO.Models.ErrorViewModel()
                    {
                        HasError = true,
                        MsgError = ex.Message,
                        RequestId = user,

                    }
                };

                return View("Error", model);
            }            
        }
    }
}
