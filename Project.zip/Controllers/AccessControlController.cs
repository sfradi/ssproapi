﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Portal.SSPRO.ViewModels;
using SSPRO.Web.Cache;
using SSPRO.Web.Models;
using SSPRO.Web.Services;

namespace SSPRO.Web.Controllers
{
    [Route("AccessControl")]

    public class AccessControlController : Controller
    {
        
        AccessControlService _accessControlService;
        AccountService _accountService;
      
        LoginCached _loginCached;

        public AccessControlController(IMemoryCache memoryCache)
        {
          
            _accessControlService = new AccessControlService(memoryCache);
            _accountService = new AccountService(memoryCache);
        
            _loginCached = new LoginCached(memoryCache);
        }

        [HttpGet("Index")]
        public IActionResult Index(string sessionToken)
        {
            ApplicationViewModel model = new ApplicationViewModel()
            {
                SessionToken = sessionToken,
            };

            return View("AccessControlPanel", model);
        }


        [HttpGet("GetPanelList")]
        public async Task<IActionResult> GetPanelList(string sessionToken)
        {
            ApplicationViewModel model = new ApplicationViewModel();
            try
            {
                var userCached = _loginCached.GetLoginCache(sessionToken);

                var productId = userCached.ProductId - 1000;

                var accounts = _accountService.GetAllAccountInfo(userCached);

                //var yohanAccounts = _yohanAccountService.GetAllAccountsByAccount(sessionToken, (int)accounts.FirstOrDefault().Id, userCached);

                //var actionList = _accessControlService.GetActionsByAccount((int)accounts.FirstOrDefault().Id, productId, sessionToken);

                model = new ApplicationViewModel()
                {
                    SessionToken = sessionToken,
                    acActionList = null,
                    accountList = accounts,
                    //yohanAccountList = yohanAccounts,
                };

            }
            catch (Exception ex)
            {
                model = new ApplicationViewModel()
                {
                    SessionToken = sessionToken,
                    errorViewModel = new Portal.SSPRO.Models.ErrorViewModel()
                    {
                        HasError = true,
                        MsgError = ex.Message,
                        RequestId = sessionToken
                    }
                };

                return View("Error", model);
            }

            return View("PanelList", model);
        }
  

 

        [HttpGet("Test")]
        public IActionResult Test(string sessionToken)
        {
            ApplicationViewModel model = new ApplicationViewModel()
            {
                SessionToken = sessionToken,
            };

            return View("AccessControlPanel", model);
        }


        
    }

}