﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.Options;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SS.Shared.BackOffice.Interfaces;
using SS.Shared.BackOffice.Services;
using SS.Shared.Logger.Interfaces;
using SS.Shared.Logger.Services;
using SSPRO.Web.Interfaces;
using SSPRO.Web.Services;

namespace SSPRO.Web
{
    public class Startup
    {
        ILogger<object> logger;      
        IHostingEnvironment environment;
        Microsoft.Extensions.Options.IOptions<MemoryCacheOptions> options;
        IMemoryCache _memorycache;   

        public Startup(IConfiguration configuration, ILogger<object> logger, IHostingEnvironment environment)
        {
            Configuration = configuration;
            options = new MemoryCacheOptions();
            _memorycache = new MemoryCache(options);      
            this.logger = logger;
            this.environment = environment;

            SS.Shared.Parameters.Services.ParametersService parametersService = new SS.Shared.Parameters.Services.ParametersService(_memorycache);
            parametersService.LoadProductParams(SS.Shared.Parameters.Enums.ProductTypeEnum.SS_PRO_Web);

            MainService identServices = new MainService(_memorycache);
            identServices.StartDataList();          
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //services.Configure<CookiePolicyOptions>(options =>
            //{
            //    options.CheckConsentNeeded = context => true;
            //    options.MinimumSameSitePolicy = SameSiteMode.None;
            //});


           
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            services.AddMemoryCache();

            services.AddSingleton<SS.Shared.Logger.Interfaces.ILoggerService>(s => new SS.Shared.Logger.Services.LoggerService(logger, _memorycache, this.environment));
            services.AddTransient<IMainService>(s => new MainService(_memorycache));
            services.AddTransient<IBackOfficeService>(b => new BackOfficeService());
            services.AddProgressiveWebApp();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            //if (env.IsDevelopment())
            //{
            //    app.UseDeveloperExceptionPage();
            //}
            //else
            //{
            //    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
            //    app.UseHsts();
            //}

            //app.UseHttpsRedirection();
            //app.UseMvc();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();
            app.UseCors(option => option.AllowAnyOrigin());


            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Login}/{action=Index}/{id?}");
            });
        }
    }
}
