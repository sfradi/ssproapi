﻿using Microsoft.Extensions.Caching.Memory;
using Portal.SSPRO.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using SSPRO.Web.Entities;
using SSPRO.Web.Global;
using SSPRO.Web.Enums;

namespace SSPRO.Web.Repositories
{
    public class LoginRepository
    {
        DatabaseConfig _dbShared;

        public LoginRepository(IMemoryCache memoryCache)
        {
            _dbShared = new DatabaseConfig(memoryCache);
        }

        public LoginEntity GetLoginInfo(string userName)
        {
            LoginEntity login = new LoginEntity();

            using (SqlConnection cn = new SqlConnection(_dbShared.connStringShared()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = $"SELECT * FROM UserLogin WHERE UserName=@UserName AND ProductId=@ProductId ";
                    cmd.Parameters.AddWithValue("@UserName", userName);
                    cmd.Parameters.AddWithValue("@ProductId", (int)ProductTypeEnum.SSPRO_Web);

                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        login = new LoginEntity()
                        {
                            id = (long)dr.GetValue(dr.GetOrdinal("Id")),
                            AccessGroup = (int)dr.GetValue(dr.GetOrdinal("AccessGroup")),
                            AccountId = (long)dr.GetValue(dr.GetOrdinal("AccountId")),
                            AuthKey = dr.GetValue(dr.GetOrdinal("AuthKey")).ToString(),
                            CelPhone = dr.GetValue(dr.GetOrdinal("CelPhone")).ToString(),
                            email = dr.GetValue(dr.GetOrdinal("email")).ToString(),
                            Name = dr.GetValue(dr.GetOrdinal("Name")).ToString(),
                            Password = dr.GetValue(dr.GetOrdinal("Password")).ToString(),
                            ProductId = (int)dr.GetValue(dr.GetOrdinal("ProductId")),
                            ProfileImage64 = dr.GetValue(dr.GetOrdinal("ProfileImage")).ToString(),
                            RememberKey = dr.GetValue(dr.GetOrdinal("RememberKey")).ToString(),                            
                            Status = (int)dr.GetValue(dr.GetOrdinal("Status")),
                            Type = (int)dr.GetValue(dr.GetOrdinal("Type")),
                            Unity = dr.GetValue(dr.GetOrdinal("Unity")).ToString(),
                            UserName = dr.GetValue(dr.GetOrdinal("UserName")).ToString(),
                        };
                    }
                    cn.Close();
                    return login;
                }
                catch (Exception ex)
                {
                    throw ex;
                }             
            }
        }
    }
}
