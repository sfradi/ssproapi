﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Entities;
using SSPRO.Web.Global;
using SSPRO.Web.Models;

namespace SSPRO.Web.Repositories
{
    public class AccessControlRepository
    {
        DatabaseConfig _db;

        public AccessControlRepository(IMemoryCache memoryCache)
        {
            _db = new DatabaseConfig(memoryCache);
        }

        public List<AccessControlEntity.Actions> GetActionsByAccount(int accountId, int botId, string sessionToken, SharedInfoModel.ProductsDatabaseAvailable db)
        {
            List<AccessControlEntity.Actions> actions = new List<AccessControlEntity.Actions>();

            using (SqlConnection cn = new SqlConnection(_db.connStringByContext(db)))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = "SELECT * FROM dbo.TB_ACCESS_CONTROL_ACTIONS WHERE accountId=@accountId AND botId=@botId";
                    cmd.Parameters.AddWithValue("@accountId", accountId);
                    cmd.Parameters.AddWithValue("@botId", botId);

                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        actions.Add(new AccessControlEntity.Actions()
                        {
                            Id = (long)dr.GetValue(dr.GetOrdinal("Id")),
                            AccountId = (int)dr.GetValue(dr.GetOrdinal("AccountId")),
                            BotId = (int)dr.GetValue(dr.GetOrdinal("BotId")),
                            Description = dr.GetValue(dr.GetOrdinal("Description")).ToString(),
                            Btn1Active = (bool)dr.GetValue(dr.GetOrdinal("Btn1Active")),
                            Btn2Active = (bool)dr.GetValue(dr.GetOrdinal("Btn2Active")),
                            Btn1DeviceId = (int)dr.GetValue(dr.GetOrdinal("Btn1DeviceId")),
                            Btn2DeviceId = (int)dr.GetValue(dr.GetOrdinal("Btn2DeviceId")),
                            BtnLabel1 = dr.GetValue(dr.GetOrdinal("BtnLabel1")).ToString(),
                            BtnLabel2 = dr.GetValue(dr.GetOrdinal("BtnLabel2")).ToString(),
                            CameraId = (int)dr.GetValue(dr.GetOrdinal("CameraId")),
                            PanelPosition = (int)dr.GetValue(dr.GetOrdinal("PanelPosition")),
                            Type = (int)dr.GetValue(dr.GetOrdinal("Type")),
                            IsActive = (bool)dr.GetValue(dr.GetOrdinal("IsActive")),
                        });
                    }

                    cn.Close();

                    return actions;
                }
                catch (Exception ex)
                {
                }

                return actions;
            }


        }

        public AccessControlEntity.Actions GetActionsById(int accountId, int botId, int actionId, string sessionToken, SharedInfoModel.ProductsDatabaseAvailable db)
        {
            AccessControlEntity.Actions action = new AccessControlEntity.Actions();

            using (SqlConnection cn = new SqlConnection(_db.connStringByContext(db)))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = "SELECT * FROM dbo.TB_ACCESS_CONTROL_ACTIONS WHERE accountId=@accountId AND botId=@botId AND id=@id";
                    cmd.Parameters.AddWithValue("@accountId", accountId);
                    cmd.Parameters.AddWithValue("@botId", botId);
                    cmd.Parameters.AddWithValue("@Id", actionId);

                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        action = new AccessControlEntity.Actions()
                        {
                            Id = (long)dr.GetValue(dr.GetOrdinal("Id")),
                            AccountId = (int)dr.GetValue(dr.GetOrdinal("AccountId")),
                            BotId = (int)dr.GetValue(dr.GetOrdinal("BotId")),
                            Description = dr.GetValue(dr.GetOrdinal("Description")).ToString(),
                            Btn1Active = (bool)dr.GetValue(dr.GetOrdinal("Btn1Active")),
                            Btn2Active = (bool)dr.GetValue(dr.GetOrdinal("Btn2Active")),
                            Btn1DeviceId = (int)dr.GetValue(dr.GetOrdinal("Btn1DeviceId")),
                            Btn2DeviceId = (int)dr.GetValue(dr.GetOrdinal("Btn2DeviceId")),
                            BtnLabel1 = dr.GetValue(dr.GetOrdinal("BtnLabel1")).ToString(),
                            BtnLabel2 = dr.GetValue(dr.GetOrdinal("BtnLabel2")).ToString(),
                            CameraId = (int)dr.GetValue(dr.GetOrdinal("CameraId")),
                            PanelPosition = (int)dr.GetValue(dr.GetOrdinal("PanelPosition")),
                            Type = (int)dr.GetValue(dr.GetOrdinal("Type")),
                            IsActive = (bool)dr.GetValue(dr.GetOrdinal("IsActive")),
                        };
                    }

                    cn.Close();

                    return action;
                }
                catch (Exception ex)
                {
                }

                return action;
            }


        }

        public List<AccessControlEntity.Devices> GetDevicesByAccount(int accountId, int botId, string sessionToken, SharedInfoModel.ProductsDatabaseAvailable db)
        {
            List<AccessControlEntity.Devices> devices = new List<AccessControlEntity.Devices>();

            using (SqlConnection cn = new SqlConnection(_db.connStringByContext(db)))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = "SELECT * FROM dbo.TB_ACCESS_CONTROL_DEVICES WHERE accountId=@accountId AND botId=@botId";
                    cmd.Parameters.AddWithValue("@accountId", accountId);
                    cmd.Parameters.AddWithValue("@botId", botId);                    

                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        devices.Add(new AccessControlEntity.Devices()
                        {
                            Id = (long)dr.GetValue(dr.GetOrdinal("Id")),
                            AccountId = (int)dr.GetValue(dr.GetOrdinal("AccountId")),
                            BotId = (int)dr.GetValue(dr.GetOrdinal("BotId")),
                            Description = dr.GetValue(dr.GetOrdinal("Description")).ToString(),
                            Type = (int)dr.GetValue(dr.GetOrdinal("Type")),
                            Model = (int)dr.GetValue(dr.GetOrdinal("Model")),
                            IP = dr.GetValue(dr.GetOrdinal("IP")).ToString(),
                            Port = (int)dr.GetValue(dr.GetOrdinal("Port")),
                            DeviceId = (int)dr.GetValue(dr.GetOrdinal("DeviceId")),
                            DeviceOut = (int)dr.GetValue(dr.GetOrdinal("DeviceOut")),
                            DeviceModule = (int)dr.GetValue(dr.GetOrdinal("DeviceModule")),
                            Url = dr.GetValue(dr.GetOrdinal("Url")).ToString(),
                            JsonCFG = dr.GetValue(dr.GetOrdinal("JsonCFG")).ToString(),
                            IsActive = (bool)dr.GetValue(dr.GetOrdinal("IsActive")),
                        });
                    }

                    cn.Close();

                    return devices;
                }
                catch (Exception ex)
                {
                }

                return devices;
            }


        }

        public int GetActionsCounter(int accountId, int botId, string sessionToken, SharedInfoModel.ProductsDatabaseAvailable db)
        {
            int count = 0;

            using (SqlConnection cn = new SqlConnection(_db.connStringByContext(db)))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = "SELECT COUNT(Id) FROM dbo.TB_ACCESS_CONTROL_ACTIONS WHERE accountId=@accountId AND botId=@botId";
                    cmd.Parameters.AddWithValue("@accountId", accountId);
                    cmd.Parameters.AddWithValue("@botId", botId);

                    count = (int)cmd.ExecuteScalar();

                    cn.Close();

                    return count;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return count;
            }


        }

        public bool InsertPanel(AccessControlEntity.Actions actions, string sessionToken, SharedInfoModel.ProductsDatabaseAvailable db)
        {

            using (SqlConnection cn = new SqlConnection(_db.connStringByContext(db)))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = "INSERT INTO TB_ACCESS_CONTROL_ACTIONS (Type, Description, PanelPosition, BtnLabel1, BtnLabel2, Btn1DeviceId, Btn2DeviceId, " +
                        "Btn1Active, Btn2Active, CameraId, AccountId, BotId, IsActive) VALUES (@Type, @Description, @PanelPosition, @BtnLabel1, @BtnLabel2, @Btn1DeviceId, @Btn2DeviceId," +
                        "@Btn1Active, @Btn2Active, @CameraId, @AccountId, @BotId, @IsActive)";

                    //cmd.Parameters.AddWithValue("Id", actions.Id);
                    cmd.Parameters.AddWithValue("Type", actions.Type);
                    cmd.Parameters.AddWithValue("Description", actions.Description);
                    cmd.Parameters.AddWithValue("PanelPosition", actions.PanelPosition);
                    cmd.Parameters.AddWithValue("BtnLabel1", actions.BtnLabel1);
                    cmd.Parameters.AddWithValue("BtnLabel2", actions.BtnLabel2);
                    cmd.Parameters.AddWithValue("Btn1DeviceId", actions.Btn1DeviceId);
                    cmd.Parameters.AddWithValue("Btn2DeviceId", actions.Btn2DeviceId);
                    cmd.Parameters.AddWithValue("Btn1Active", actions.Btn1Active);
                    cmd.Parameters.AddWithValue("Btn2Active", actions.Btn2Active);
                    cmd.Parameters.AddWithValue("CameraId", actions.CameraId);
                    cmd.Parameters.AddWithValue("AccountId", actions.AccountId);
                    cmd.Parameters.AddWithValue("BotId", actions.BotId);
                    cmd.Parameters.AddWithValue("IsActive", actions.IsActive);

                    cmd.ExecuteNonQuery();

                    cn.Close();

                    return true;

                }
                catch (Exception ex)
                {
                    throw ex;
                }         

            }

        }

        public bool UpdatePanel(AccessControlEntity.Actions actions, string sessionToken, SharedInfoModel.ProductsDatabaseAvailable db)
        {

            using (SqlConnection cn = new SqlConnection(_db.connStringByContext(db)))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = "UPDATE TB_ACCESS_CONTROL_ACTIONS SET Type=@Type, Description=@Description, PanelPosition=@PanelPosition, BtnLabel1=@BtnLabel1," +
                        "BtnLabel2=@BtnLabel2, Btn1DeviceId=@Btn1DeviceId, Btn2DeviceId=@Btn2DeviceId, Btn1Active=Btn1Active, Btn2Active=@Btn2Active, CameraId=@CameraId," +
                        "AccountId=@AccountId, BotId=@BotId, IsActive=@IsActive WHERE Id=@Id AND AccountId=@AccountId AND BotId=@BotId";

                    cmd.Parameters.AddWithValue("Id", actions.Id);
                    cmd.Parameters.AddWithValue("Type", actions.Type);
                    cmd.Parameters.AddWithValue("Description", actions.Description);
                    cmd.Parameters.AddWithValue("PanelPosition", actions.PanelPosition);
                    cmd.Parameters.AddWithValue("BtnLabel1", actions.BtnLabel1);
                    cmd.Parameters.AddWithValue("BtnLabel2", actions.BtnLabel2);
                    cmd.Parameters.AddWithValue("Btn1DeviceId", actions.Btn1DeviceId);
                    cmd.Parameters.AddWithValue("Btn2DeviceId", actions.Btn2DeviceId);
                    cmd.Parameters.AddWithValue("Btn1Active", actions.Btn1Active);
                    cmd.Parameters.AddWithValue("Btn2Active", actions.Btn2Active);
                    cmd.Parameters.AddWithValue("CameraId", actions.CameraId);
                    cmd.Parameters.AddWithValue("AccountId", actions.AccountId);
                    cmd.Parameters.AddWithValue("BotId", actions.BotId);
                    cmd.Parameters.AddWithValue("IsActive", actions.IsActive);

                    cmd.ExecuteNonQuery();

                    cn.Close();

                    return true;

                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }

        }

        public bool DeletePanel(AccessControlEntity.Actions actions, string sessionToken, SharedInfoModel.ProductsDatabaseAvailable db )
        {
            using (SqlConnection cn = new SqlConnection(_db.connStringByContext(db)))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = "DELETE FROM TB_ACCESS_CONTROL_ACTIONS WHERE Id=@id AND botId=@botId AND accountId=@accountId";
                    cmd.Parameters.AddWithValue("Id", actions.Id);
                    cmd.Parameters.AddWithValue("botId", actions.BotId);
                    cmd.Parameters.AddWithValue("accountId", actions.AccountId);
                    cmd.ExecuteNonQuery();
                    cn.Close();
                    return true;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

        }
    }
}