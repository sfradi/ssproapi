﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Entities;
using SSPRO.Web.Global;

namespace SSPRO.Web.Repositories
{
    public class AccountRepository
    {
        DatabaseConfig _db;

        public AccountRepository(IMemoryCache memoryCache)
        {
            _db = new DatabaseConfig(memoryCache);
        }

        public List<AccountEntity> GetAllAccountInfo()
        {
            string result = "";

            List<AccountEntity> accounts = new List<AccountEntity>();

            using (SqlConnection cn = new SqlConnection(_db.connStringShared()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = "SELECT * FROM dbo.ClientAccount";

                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        accounts.Add(new AccountEntity
                        {
                            Id = (long)dr.GetValue(dr.GetOrdinal("id")),
                            Name = dr.GetValue(dr.GetOrdinal("Name")).ToString(),
                            CPFCNPJ = dr.GetValue(dr.GetOrdinal("CNPJ")).ToString(),
                            Email = dr.GetValue(dr.GetOrdinal("Email")).ToString(),
                            //account.BotsCount = (int)dr.GetValue(dr.GetOrdinal("BotsCount")),
                            Phone = dr.GetValue(dr.GetOrdinal("Phone")).ToString(),
                            CelPhone = dr.GetValue(dr.GetOrdinal("CelPhone")).ToString(),
                            Address = dr.GetValue(dr.GetOrdinal("Address")).ToString(),
                            Number = dr.GetValue(dr.GetOrdinal("Number")).ToString(),
                            Neighborhood = dr.GetValue(dr.GetOrdinal("Neighborhood")).ToString(),
                            City = dr.GetValue(dr.GetOrdinal("City")).ToString(),
                            State = dr.GetValue(dr.GetOrdinal("State")).ToString(),
                            ZipCode = dr.GetValue(dr.GetOrdinal("ZipCode")).ToString(),
                            Contact = dr.GetValue(dr.GetOrdinal("Contact")).ToString(),
                            Status = (int)dr.GetValue(dr.GetOrdinal("Status")),
                            TermOfResponsability = dr.GetValue(dr.GetOrdinal("TermOfResponsability")).ToString(),
                        });
                    }

                    cn.Close();
                }
                catch (Exception ex)
                {
                    //LOGGER NOT FOUND TO ACCOUNT AND BOTID
                    throw ex;
                }
            }

            return accounts;
        }

        public List<AccountEntity> GetAllAccountInfo(int accountId)
        {
            string result = "";

            List<AccountEntity> accounts = new List<AccountEntity>();

            using (SqlConnection cn = new SqlConnection(_db.connStringShared()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = "SELECT * FROM dbo.ClientAccount WHERE Id=@Id";
                    cmd.Parameters.AddWithValue("@Id", accountId);

                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        accounts.Add(new AccountEntity
                        {
                            Id = (long)dr.GetValue(dr.GetOrdinal("id")),
                            Name = dr.GetValue(dr.GetOrdinal("Name")).ToString(),
                            CPFCNPJ = dr.GetValue(dr.GetOrdinal("CNPJ")).ToString(),
                            Email = dr.GetValue(dr.GetOrdinal("Email")).ToString(),
                            //account.BotsCount = (int)dr.GetValue(dr.GetOrdinal("BotsCount")),
                            Phone = dr.GetValue(dr.GetOrdinal("Phone")).ToString(),
                            CelPhone = dr.GetValue(dr.GetOrdinal("CelPhone")).ToString(),
                            Address = dr.GetValue(dr.GetOrdinal("Address")).ToString(),
                            Number = dr.GetValue(dr.GetOrdinal("Number")).ToString(),
                            Neighborhood = dr.GetValue(dr.GetOrdinal("Neighborhood")).ToString(),
                            City = dr.GetValue(dr.GetOrdinal("City")).ToString(),
                            State = dr.GetValue(dr.GetOrdinal("State")).ToString(),
                            ZipCode = dr.GetValue(dr.GetOrdinal("ZipCode")).ToString(),
                            Contact = dr.GetValue(dr.GetOrdinal("Contact")).ToString(),
                            Status = (int)dr.GetValue(dr.GetOrdinal("Status")),
                            TermOfResponsability = dr.GetValue(dr.GetOrdinal("TermOfResponsability")).ToString(),
                        });
                    }

                    cn.Close();
                }
                catch (Exception ex)
                {
                    //LOGGER NOT FOUND TO ACCOUNT AND BOTID
                    throw ex;
                }
            }

            return accounts;
        }

        public AccountEntity GetAccountInfo(long accountId)
        {
            string result = "";

            AccountEntity account = new AccountEntity();

            using (SqlConnection cn = new SqlConnection(_db.connStringShared()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = "SELECT * FROM dbo.ClientAccount WHERE Id=@Id";
                    cmd.Parameters.AddWithValue("@Id", accountId);

                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        account.Id = (long)dr.GetValue(dr.GetOrdinal("id"));
                        account.Name = dr.GetValue(dr.GetOrdinal("Name")).ToString();
                        account.CPFCNPJ = dr.GetValue(dr.GetOrdinal("CNPJ")).ToString();
                        account.Email = dr.GetValue(dr.GetOrdinal("Email")).ToString();
                        //account.BotsCount = (int)dr.GetValue(dr.GetOrdinal("BotsCount"));
                        account.Phone = dr.GetValue(dr.GetOrdinal("Phone")).ToString();
                        account.CelPhone = dr.GetValue(dr.GetOrdinal("CelPhone")).ToString();
                        account.Address = dr.GetValue(dr.GetOrdinal("Address")).ToString();
                        account.Number = dr.GetValue(dr.GetOrdinal("Number")).ToString();
                        account.Neighborhood = dr.GetValue(dr.GetOrdinal("Neighborhood")).ToString();
                        account.City = dr.GetValue(dr.GetOrdinal("City")).ToString();
                        account.State = dr.GetValue(dr.GetOrdinal("State")).ToString();
                        account.ZipCode = dr.GetValue(dr.GetOrdinal("ZipCode")).ToString();
                        account.Contact = dr.GetValue(dr.GetOrdinal("Contact")).ToString();
                        account.Status = (int)dr.GetValue(dr.GetOrdinal("Status"));
                        account.TermOfResponsability = dr.GetValue(dr.GetOrdinal("TermOfResponsability")).ToString();

                    }

                    cn.Close();
                }
                catch (Exception ex)
                {
                    //LOGGER NOT FOUND TO ACCOUNT AND BOTID
                    throw ex;
                }
            }

            return account;
        }

        public bool InsertAccount(AccountEntity accountEntity)
        {
            using (SqlConnection cn = new SqlConnection(_db.connStringShared()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = "INSERT INTO dbo.ClientAccount (Name,CNPJ,Address,Number,Neighborhood,City," +
                        "State,ZipCode,Contact,email,Phone,CelPhone,Status,Responsability, " +
                        "ReponsabilityPhone,ResponsabilityCelPhone,TermOfResponsability) VALUES (@Name,@CNPJ,@Address,@Number,@Neighborhood,@City," +
                        "@State,@ZipCode,@Contact,@email,@Phone,@CelPhone,@Status,@Responsability,@ReponsabilityPhone,@ResponsabilityCelPhone,@TermOfResponsability)";

                    cmd.Parameters.AddWithValue("@Name", accountEntity.Name);
                    cmd.Parameters.AddWithValue("@CNPJ", accountEntity.CPFCNPJ);
                    cmd.Parameters.AddWithValue("@Address", accountEntity.Address);
                    cmd.Parameters.AddWithValue("@Number", accountEntity.Number);
                    cmd.Parameters.AddWithValue("@Neighborhood", accountEntity.Neighborhood);
                    cmd.Parameters.AddWithValue("@City", accountEntity.City);
                    cmd.Parameters.AddWithValue("@State", accountEntity.State);
                    cmd.Parameters.AddWithValue("@ZipCode", accountEntity.ZipCode);
                    cmd.Parameters.AddWithValue("@Contact", accountEntity.Contact);
                    cmd.Parameters.AddWithValue("@email", accountEntity.Email);
                    cmd.Parameters.AddWithValue("@Phone", accountEntity.Phone);
                    cmd.Parameters.AddWithValue("@CelPhone", accountEntity.CelPhone);
                    cmd.Parameters.AddWithValue("@Status", accountEntity.Status);
                    cmd.Parameters.AddWithValue("@Responsability", "");
                    cmd.Parameters.AddWithValue("@ReponsabilityPhone", "");
                    cmd.Parameters.AddWithValue("@ResponsabilityCelPhone", "");
                    cmd.Parameters.AddWithValue("@TermOfResponsability", accountEntity.TermOfResponsability);

                    cmd.ExecuteNonQuery();

                    cn.Close();

                    return true;

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return false;

            }
        }

        public bool UpdateAccount(AccountEntity accountEntity)
        {
            using (SqlConnection cn = new SqlConnection(_db.connStringShared()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = "UPDATE dbo.ClientAccount SET Name=@Name, CNPJ=@CNPJ, Address=@Address, Number=@Number, Neighborhood=@Neighborhood, City=@City," +
                        "State=@State, ZipCode=@ZipCode, Contact=@Contact, email=@email, Phone=@Phone, CelPhone=@CelPhone, Status=@Status, Responsability=@Responsability, " +
                        "ReponsabilityPhone=@ReponsabilityPhone, ResponsabilityCelPhone=@ResponsabilityCelPhone, TermOfResponsability=@TermOfResponsability WHERE Id=@Id";
                    cmd.Parameters.AddWithValue("@Id", accountEntity.Id);
                    cmd.Parameters.AddWithValue("@Name", accountEntity.Name);
                    cmd.Parameters.AddWithValue("@CNPJ", accountEntity.CPFCNPJ);
                    cmd.Parameters.AddWithValue("@Address", accountEntity.Address);
                    cmd.Parameters.AddWithValue("@Number", accountEntity.Number);
                    cmd.Parameters.AddWithValue("@Neighborhood", accountEntity.Neighborhood);
                    cmd.Parameters.AddWithValue("@City", accountEntity.City);
                    cmd.Parameters.AddWithValue("@State", accountEntity.State);
                    cmd.Parameters.AddWithValue("@ZipCode", accountEntity.ZipCode);
                    cmd.Parameters.AddWithValue("@Contact", accountEntity.Contact);
                    cmd.Parameters.AddWithValue("@email", accountEntity.Email);
                    cmd.Parameters.AddWithValue("@Phone", accountEntity.Phone);
                    cmd.Parameters.AddWithValue("@CelPhone", accountEntity.CelPhone);
                    cmd.Parameters.AddWithValue("@Status", accountEntity.Status);
                    cmd.Parameters.AddWithValue("@Responsability", "");
                    cmd.Parameters.AddWithValue("@ReponsabilityPhone", "");
                    cmd.Parameters.AddWithValue("@ResponsabilityCelPhone", "");
                    cmd.Parameters.AddWithValue("@TermOfResponsability", accountEntity.TermOfResponsability);

                    cmd.ExecuteNonQuery();

                    cn.Close();

                    return true;

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return false;

            }
        }
    }
}
