﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Entities;
using SSPRO.Web.Global;

namespace SSPRO.Web.Repositories
{
    public class SharedParametersRepository
    {
        DatabaseConfig _sharedDb;

        public SharedParametersRepository(IMemoryCache memoryCache)
        {
            _sharedDb = new DatabaseConfig(memoryCache);
        }

        public List<SharedParametersEntity> GetParameters(long accountId, long productId, int loginType)
        {
            List<SharedParametersEntity> parametersEntity = new List<SharedParametersEntity>();

            var query = "";

            switch (loginType)
            {
                case 1:
                    query = "SELECT * FROM dbo.Parameter WHERE ProductId BETWEEN 1000 AND 1999";
                    break;
                case 2:
                    query = "SELECT * FROM dbo.Parameter WHERE AccountId=@AccountId AND  ProductId BETWEEN 1000 AND 1999";
                    break;
                case 3:
                    query = "SELECT * FROM dbo.Parameter WHERE AccountId=@AccountId AND productId=@productId";
                    break;
                case 4:
                    query = "SELECT * FROM dbo.Parameter WHERE AccountId=@AccountId AND productId=@productId";
                    break;
            }

            using (SqlConnection cn = new SqlConnection(_sharedDb.connStringShared()))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("", cn);

                    cn.Open();
                    cmd.CommandText = query;
                    cmd.Parameters.AddWithValue("@AccountId", accountId);
                    cmd.Parameters.AddWithValue("@productId", productId);

                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        parametersEntity.Add(new SharedParametersEntity()
                        {
                            id = (long)dr.GetValue(dr.GetOrdinal("Id")),
                            AccountId = (long)dr.GetValue(dr.GetOrdinal("AccountId")),
                            ParamName = dr.GetValue(dr.GetOrdinal("ParamName")).ToString(),
                            DataParam = dr.GetValue(dr.GetOrdinal("DataParam")).ToString(),
                            ProductId = (int)dr.GetValue(dr.GetOrdinal("ProductId")),
                            Status = (int)dr.GetValue(dr.GetOrdinal("Status")),
                        });
                    }

                    cn.Close();

                    return parametersEntity;
                }
                catch (Exception ex)
                {
                }

                return parametersEntity;
            }

        }
    }
}
