﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Models;

namespace SSPRO.Web.Interfaces
{
    public interface IMainService
    {
        void StartDataList();

        List<IdentifiersModel.Cards> GetCardList();

    }
}
