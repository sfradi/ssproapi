﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Global
{
    public class GlobalInfo
    {
        public static string pass = "AGEMSTAR2016253647";


    }
}
