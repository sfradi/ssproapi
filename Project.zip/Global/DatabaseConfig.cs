﻿ 
using Microsoft.AspNetCore.Identity.UI.V3.Pages.Internal.Account;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using SSPRO.Web.Cache;
using SSPRO.Web.Entities;
using SSPRO.Web.Models;
using static SSPRO.Web.Models.JsonConverterModel;

namespace SSPRO.Web.Global
{
    public class DatabaseConfig
    {
        public string DS, IC;

        IMemoryCache _memoryCache;
        SharedParametersCached _sharedParameters;
        LoginCached _login;

        public DatabaseConfig(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
            _sharedParameters = new SharedParametersCached(_memoryCache);
            _login = new LoginCached(_memoryCache);
        }

        public string connStringShared()
        {          
            string filename = @"C:\config\shared.xml";
            string UID, PWD;

            DS = "";
            IC = "";
            UID = "";
            PWD = "";                  

            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(filename); //Carregando o arquivo

                //Pegando elemento pelo nome da TAG
                XmlNodeList xnList = xmlDoc.GetElementsByTagName("DataBase");

                //Usando for para imprimir na tela
                for (int i = 0; i < xnList.Count; i++)
                {
                    DS = xnList[i]["DS"].InnerText;
                    IC = xnList[i]["IC"].InnerText;
                    UID = xnList[i]["UID"].InnerText;
                    PWD = xnList[i]["PWD"].InnerText;                    
                }

                //GERA A STRING DE CONEXAO COM O BANCO
                SqlConnectionStringBuilder sqlSB = new SqlConnectionStringBuilder();
                sqlSB.InitialCatalog = IC;
                sqlSB.UserID = UID;
                sqlSB.DataSource = DS;
                sqlSB.Password = PWD;
                sqlSB.MinPoolSize = 1;
                sqlSB.MaxPoolSize = 75;

                //sqlSB.ConnectTimeout = 600;
                return sqlSB.ToString();
            }
            catch (Exception ex)
            {                
            }

            return "";
        }
        
        public string connString(string sessionToken, long accountId, long botId)
        {
            var login = _login.GetLoginCache(sessionToken);

            var productId = botId + 1000;

            var paramCached = botId > 0 ? _sharedParameters.GetSharedParamCache(sessionToken).Where(x => x.AccountId == accountId && x.ProductId == productId) :
                _sharedParameters.GetSharedParamCache(sessionToken).Where(x => x.AccountId == accountId);
            
            var databaseinfo = JsonConvert.DeserializeObject<DatabaseConfigModel>(paramCached.Where(x => x.ParamName == "Databaseconfig").FirstOrDefault().DataParam);

          

            string filename = AppDomain.CurrentDomain.BaseDirectory + "cfg.xml";
            string UID, PWD;

            DS = databaseinfo.DS;
            IC = databaseinfo.IC;
            UID = databaseinfo.UID;
            PWD = databaseinfo.PWD;

            try
            {
                //XmlDocument xmlDoc = new XmlDocument();
                //xmlDoc.Load(filename); //Carregando o arquivo

                ////Pegando elemento pelo nome da TAG
                //XmlNodeList xnList = xmlDoc.GetElementsByTagName("DataBase");

                ////Usando for para imprimir na tela
                //for (int i = 0; i < xnList.Count; i++)
                //{
                //    DS = xnList[i]["DS"].InnerText;
                //    IC = xnList[i]["IC"].InnerText;
                //    UID = xnList[i]["UID"].InnerText;
                //    PWD = xnList[i]["PWD"].InnerText;
                //    PWD = Cript.DeCriptSenha(PWD, GlobalInfo.pass).ToString();                   
                //}

                //GERA A STRING DE CONEXAO COM O BANCO
                SqlConnectionStringBuilder sqlSB = new SqlConnectionStringBuilder();
                sqlSB.InitialCatalog = IC;
                sqlSB.UserID = UID;
                sqlSB.DataSource = DS;
                sqlSB.Password = PWD;
                sqlSB.MinPoolSize = 1;
                sqlSB.MaxPoolSize = 75;               

                //sqlSB.ConnectTimeout = 600;
                return sqlSB.ToString();
            }
            catch (Exception ex)
            {

            }

            return "";
        }

        public string connStringByContext(SharedInfoModel.ProductsDatabaseAvailable db)
        {           

            
            string filename = AppDomain.CurrentDomain.BaseDirectory + "cfg.xml";
            string UID, PWD;

            DS = db.DbDataSource;
            IC = db.DbName;
            UID = db.DbUID;
            PWD = db.DbPwd;

            try
            {
                //XmlDocument xmlDoc = new XmlDocument();
                //xmlDoc.Load(filename); //Carregando o arquivo

                ////Pegando elemento pelo nome da TAG
                //XmlNodeList xnList = xmlDoc.GetElementsByTagName("DataBase");

                ////Usando for para imprimir na tela
                //for (int i = 0; i < xnList.Count; i++)
                //{
                //    DS = xnList[i]["DS"].InnerText;
                //    IC = xnList[i]["IC"].InnerText;
                //    UID = xnList[i]["UID"].InnerText;
                //    PWD = xnList[i]["PWD"].InnerText;
                //    PWD = Cript.DeCriptSenha(PWD, GlobalInfo.pass).ToString();                   
                //}

                //GERA A STRING DE CONEXAO COM O BANCO
                SqlConnectionStringBuilder sqlSB = new SqlConnectionStringBuilder();
                sqlSB.InitialCatalog = IC;
                sqlSB.UserID = UID;
                sqlSB.DataSource = DS;
                sqlSB.Password = PWD;
                sqlSB.MinPoolSize = 1;
                sqlSB.MaxPoolSize = 75;

                //sqlSB.ConnectTimeout = 600;
                return sqlSB.ToString();
            }
            catch (Exception ex)
            {

            }

            return "";
        }
    }
}
