﻿using Portal.SSPRO.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Entities;

namespace Portal.SSPRO.Models
{
    public class MemoryApplicationModel
    {
        public LoginEntity loginEntity;

        public ParametersEntity ParametersEntity;

    }
}
