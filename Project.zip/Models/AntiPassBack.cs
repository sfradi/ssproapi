﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Models
{
    public class AntiPassBack
    {
        long Id { get; set; }

        string Hex { get; set; }

        int status { get; set; }
    }
}
