﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portal.SSPRO.Models
{
    public class AccountAdminModel
    {
        public long id { get; set; }

        public long AccountId { get; set; }

        public string Name { get; set; }

        public string email { get; set; }

        public string Occupation { get; set; }

        public string Phone { get; set; }

        public string CelPhone { get; set; }

        public int Type { get; set; }        
    }
}
