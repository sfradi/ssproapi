﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portal.SSPRO.Models
{
    public class UserAccountModel
    {
        public long id { get; set; }

        public long AccountId { get; set; }

        public string Name { get; set; }

        public string UserName { get; set; }

        public string Password { get; set; }

        public string email { get; set; }

        public string Unity { get; set; }

        public string ProfileImage { get; set; }

        public string RememberKey { get; set; }

        public string CelPhone { get; set; }

        public int AccessGroup { get; set; }

        public int ProductId { get; set; }

        public int Type { get; set; }

        public int Status { get; set; }

        public string AuthKey { get; set; }

        public string FromFromUserType { get; set; }

        public UserType userType { get; set; }

        public class UserType
        { 
            public int id { get; set; }

            public string Type { get; set; }
        }

    }
}
