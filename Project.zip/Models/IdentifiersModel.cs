﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Models
{
    public class IdentifiersModel
    {
        public partial class Cards
        {
            public string HEX { get; set; }

            public long UserId { get; set; }

            public int Jorney { get; set; }

            public int Group { get; set; }

        }

        public partial class PassvieVehicleTAG
        {
            public string HEX { get; set; }

            public long UserId { get; set; }

            public int Jorney { get; set; }

            public int Group { get; set; }

        }


        public partial class KEY
        {
            public string HEX { get; set; }

            public long UserId { get; set; }

            public int Jorney { get; set; }

            public int Group { get; set; }

        }



        public partial class RemoteControl
        {
            public string HEX { get; set; }

            public long UserId { get; set; }

            public int Jorney { get; set; }

            public int Group { get; set; }

        }


    }
}
