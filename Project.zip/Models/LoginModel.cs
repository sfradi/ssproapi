﻿using Portal.SSPRO.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using SSPRO.Web.Entities;

namespace SSPRO.Web.Models
{
    public class LoginModel : LoginEntity
    {
        public string SessionToken { get; set; }

        public string MsgError { get; set; }

        public string iresp { get; set; }

    }
}
