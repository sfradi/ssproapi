﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portal.SSPRO.Models
{
    public class UnityModel
    {
        public string Unity { get; set; }
    }
}
