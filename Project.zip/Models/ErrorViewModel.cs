using System;

namespace Portal.SSPRO.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

        public bool HasError { get; set; }

        public string MsgError { get; set; }
    }
}