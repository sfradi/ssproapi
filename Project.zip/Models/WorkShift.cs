﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Models
{
    public class WorkShift
    {
        long Id { get; set; }

        TimeSpan Interval_1S { get; set; }

        TimeSpan Interval_1E { get; set; }

        TimeSpan Interval_2S { get; set; }

        TimeSpan Interval_2E { get; set; }

        TimeSpan Interval_3S { get; set; }

        TimeSpan Interval_3E { get; set; }
        
        TimeSpan Interval_4S { get; set; }

        TimeSpan Interval_4E { get; set; }

    }
}

