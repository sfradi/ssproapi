﻿using SSPRO.Web.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Models
{
    public class DeviceModel
    {
        public long Id { get; set; }
        
        public Configs _Configs { get; set; }

        public List<Readers> _Readers  {get; set;}

        public List<Relays> _Relays { get; set; }

        public List<Sensors> _Sensors { get; set; }

        public List<Leds> _Leds { get; set; }

        public List<Buzzers> _Buzzers { get; set; }

        public List<DigitalInputs> _DigitalInputs { get; set; }

        public List<DigitalOutputs> _DigitalOutputs { get; set; }

        //TODO
        //SET TIMERS OF SENSORS, EVENTS
             
        public partial class Configs
        {
            public string IP { get; set; }

            public string Mask { get; set; }

            public string Gateway { get; set; }

            public int Mode { get; set; }

            public bool APB { get; set; }

            public int Serial1Baudrate { get; set; }

            public int Serial2Baudrate { get; set; }

            public int Serial3Baudrate { get; set; }

            public bool ParkControl { get; set; }

            public int ParkControlType { get; set; } //TODO Create a enum of types
        }

        public partial class Readers
        {
            public int Id { get; set; }

            public string Description { get; set; }

            public ReaderType Type { get; set; }

            public ReaderFormat Format { get; set; }

            public int Direction { get; set; }

            public int Status { get; set; }

        }

        public partial class Relays
        {
            public int Id { get; set; }

            public RelayMode RelayMode { get; set; }

            bool IsActive { get; set; }
        }

        public partial class Sensors
        {
            int Id { get; set; }
            
            SensorType SensorType { get; set; }

            bool IsActive { get; set; }
        }

        public partial class Leds
        {
            int Id { get; set; }

            bool IsActive { get; set; }
        }

        public partial class Buzzers
        {
            int Id { get; set; }

            bool IsActive { get; set; }
        }

        public partial class DigitalInputs
        {
            int Id { get; set; }

            bool IsActive { get; set; }
        }

        public partial class DigitalOutputs
        {
            int Id { get; set; }

            bool IsActive { get; set; }
        }
    }
}