﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Models
{
    public class JsonConverterModel
    {
        public partial class DatabaseConfigModel
        {
            public string DS { get; set; }
            public string IC { get; set; }
            public string UID { get; set; }
            public string PWD { get; set; }
        }

    }
}
