﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SSPRO.Web.Models;

namespace Portal.SSPRO.Models
{
    public class ProfileModel : LoginModel
    {
        public string CurrentPassword { get; set; }
        public string NewPassword { get; set; }

    }
}
