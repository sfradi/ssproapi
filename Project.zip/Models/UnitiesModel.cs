﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Models
{
    public class UnitiesModel
    {
        public long Id { get; set; }
        public int AccountId { get; set; }
        public int BotId { get; set; }
        public string Unity { get; set; }
        public string UnityCode { get; set; }
        public string SipExtension { get; set; }
        public string AnalogExtension { get; set; }
        public bool IsActive { get; set; }
    }
}
