﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSPRO.Web.Models
{
    public class AccountModel
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string CPFCNPJ { get; set; }
        public string Email { get; set; }
        public int BotsCount { get; set; }
        public string Phone { get; set; }
        public string CelPhone { get; set; }
        public string Address { get; set; }
        public string Number { get; set; }
        public string Neighborhood { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string Contact { get; set; }
        public int Status { get; set; }
        public string TermOfResponsability { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsActive { get; set; }

    }
}
