﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace SSPRO.Web
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //CreateWebHostBuilder(args).Run();
            //CreateWebHostBuilder(args).Build().Run();   
            CreateWebHostBuilder(args).Build().Run();
        }

        static string[] prm = { "http://*:5000", "http://*:5001", "http://*:5002" };


        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
      WebHost.CreateDefaultBuilder(args)
         .ConfigureLogging((hostingContext, logging) =>
         {
             logging.AddConfiguration(hostingContext.Configuration.GetSection("Logging"));
             logging.ClearProviders();
             logging.AddDebug();
             logging.AddConsole();
             logging.AddEventSourceLogger();
             logging.AddTraceSource("Information, ActivityTracing"); // Add Trace listener provider

         })
      .UseUrls("http://*:5000")
      .UseStartup<Startup>();

    }
}

//        public static IWebHost CreateWebHostBuilder(string[] args) =>
//        //public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
//            WebHost.CreateDefaultBuilder(args)
//            .UseUrls("http://*:5000")
//            //UseUrls(prm)            
//            .UseStartup<Startup>()
//            .Build();
//    }
//}
